// แผงแอดมิน: ต้องมีรหัสเข้าถึง (ตรวจที่เซิร์ฟเวอร์ทุกคำขอด้วยโทเคนแอดมิน)
import express from 'express';
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from './db.js';
import { config } from './config.js';
import { hub, isOnline, emitToUser, notifyAdmins } from './state.js';
import { pushCredits } from './wallet.js';

export const router = express.Router();

const safeEqual = (a, b) => {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
};

export function verifyAdminToken(token) {
  try {
    return jwt.verify(token, config.jwtSecret).role === 'admin';
  } catch {
    return false;
  }
}

const tries = new Map();
router.post('/login', (req, res) => {
  const now = Date.now();
  const rec = (tries.get(req.ip) || []).filter((t) => now - t < 60_000);
  if (rec.length >= 8) return res.status(429).json({ error: 'ลองผิดบ่อยเกินไป รอสักครู่' });
  if (!safeEqual(req.body?.code ?? '', config.adminCode)) {
    tries.set(req.ip, [...rec, now]);
    return res.status(401).json({ error: 'รหัสเข้าถึงไม่ถูกต้อง' });
  }
  res.json({ token: jwt.sign({ role: 'admin' }, config.jwtSecret, { expiresIn: '12h' }) });
});

function requireAdmin(req, res, next) {
  const h = req.headers.authorization || '';
  if (!verifyAdminToken(h.startsWith('Bearer ') ? h.slice(7) : '')) return res.status(401).json({ error: 'ไม่มีสิทธิ์แอดมิน' });
  next();
}
router.use(requireAdmin);

router.get('/users', async (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  const users = await prisma.user.findMany({
    where: q ? { usernameLower: { contains: q } } : undefined,
    orderBy: { id: 'asc' },
    select: { id: true, username: true, credits: true, wins: true, losses: true, createdAt: true, lastLoginAt: true },
  });
  res.json({
    users: users.map((u) => ({ ...u, online: isOnline(u.id), room: hub.userRoom.get(u.id) || null })),
    onlineCount: [...hub.sockets.keys()].filter(isOnline).length,
    rooms: hub.rooms.size,
  });
});

router.post('/users/:id/credits', async (req, res) => {
  const id = Number(req.params.id);
  const { mode } = req.body || {};
  const amount = Math.floor(Number(req.body?.amount));
  if (!Number.isFinite(amount) || amount < 0 || amount > 1_000_000_000) return res.status(400).json({ error: 'จำนวนไม่ถูกต้อง' });
  if (!['add', 'sub', 'set'].includes(mode)) return res.status(400).json({ error: 'โหมดไม่ถูกต้อง' });
  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) return res.status(404).json({ error: 'ไม่พบผู้เล่น' });
  let credits;
  if (mode === 'set') {
    credits = amount;
    await prisma.user.update({ where: { id }, data: { credits } });
  } else if (mode === 'add') {
    credits = (await prisma.user.update({ where: { id }, data: { credits: { increment: amount } } })).credits;
  } else {
    // ลบแบบ atomic ไม่ให้ต่ำกว่า 0
    const r = await prisma.user.updateMany({ where: { id, credits: { gte: amount } }, data: { credits: { decrement: amount } } });
    if (r.count === 0) await prisma.user.update({ where: { id }, data: { credits: 0 } });
    credits = (await prisma.user.findUnique({ where: { id } })).credits;
  }
  await pushCredits(id); // สะท้อนบนหน้าจอผู้เล่นที่ออนไลน์ + โต๊ะที่นั่งอยู่ทันที
  res.json({ ok: true, credits });
});

router.post('/users/:id/password', async (req, res) => {
  const id = Number(req.params.id);
  const password = req.body?.password;
  if (typeof password !== 'string' || password.length < config.passwordMin)
    return res.status(400).json({ error: `รหัสผ่านใหม่ต้องมีอย่างน้อย ${config.passwordMin} ตัวอักษร` });
  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) return res.status(404).json({ error: 'ไม่พบผู้เล่น' });
  await prisma.user.update({
    where: { id },
    data: { passwordHash: await bcrypt.hash(password, 10), tokenVersion: { increment: 1 } },
  });
  emitToUser(id, 'session:kicked', { reason: 'แอดมินรีเซ็ตรหัสผ่านของคุณ กรุณาเข้าสู่ระบบใหม่' });
  res.json({ ok: true });
});

router.delete('/users/:id', async (req, res) => {
  const id = Number(req.params.id);
  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) return res.status(404).json({ error: 'ไม่พบผู้เล่น' });
  const code = hub.userRoom.get(id);
  const room = code && hub.rooms.get(code);
  if (room) await room.leave(id, { forced: true });
  await prisma.user.delete({ where: { id } });
  emitToUser(id, 'session:kicked', { reason: 'บัญชีของคุณถูกลบโดยแอดมิน' });
  for (const s of hub.sockets.get(id) || []) s.disconnect(true);
  notifyAdmins();
  res.json({ ok: true });
});

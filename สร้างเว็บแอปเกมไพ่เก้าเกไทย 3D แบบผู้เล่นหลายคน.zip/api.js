const TOKEN_KEY = 'kaokae_token';
const ADMIN_KEY = 'kaokae_admin_token';

export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};
export const adminTokenStore = {
  get: () => sessionStorage.getItem(ADMIN_KEY),
  set: (t) => sessionStorage.setItem(ADMIN_KEY, t),
  clear: () => sessionStorage.removeItem(ADMIN_KEY),
};

export async function api(path, { method = 'GET', body, token } = {}) {
  const res = await fetch(path, {
    method,
    headers: {
      ...(body ? { 'Content-Type': 'application/json' } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try {
    data = await res.json();
  } catch {
    /* ไม่มี body */
  }
  if (!res.ok) {
    const err = new Error(data.error || `เกิดข้อผิดพลาด (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

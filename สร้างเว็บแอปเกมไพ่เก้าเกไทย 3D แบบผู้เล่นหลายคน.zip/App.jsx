import React, { useCallback, useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { api, tokenStore } from './lib/api.js';
import { play } from './lib/sound.js';
import AuthPage from './pages/AuthPage.jsx';
import Lobby from './pages/Lobby.jsx';
import GamePage from './pages/GamePage.jsx';
import Admin from './pages/Admin.jsx';

export default function App() {
  if (window.location.pathname.startsWith('/admin')) return <Admin />;
  return <Main />;
}

function Main() {
  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(true);
  const [credits, setCredits] = useState(0);
  const [rooms, setRooms] = useState([]);
  const [room, setRoom] = useState(null);
  const [connected, setConnected] = useState(false);
  const [toast, setToast] = useState(null);
  const socketRef = useRef(null);

  const notify = useCallback((text, kind = 'info') => {
    setToast({ text, kind, id: Date.now() });
  }, []);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3500);
    return () => clearTimeout(t);
  }, [toast]);

  // เข้าสู่ระบบค้างไว้: ตรวจโทเคนที่เก็บไว้ (อายุ 30 วัน)
  useEffect(() => {
    const t = tokenStore.get();
    if (!t) return setBooting(false);
    api('/api/auth/me', { token: t })
      .then((r) => {
        setUser(r.user);
        setCredits(r.user.credits);
      })
      .catch(() => tokenStore.clear())
      .finally(() => setBooting(false));
  }, []);

  const logout = useCallback(
    (message) => {
      tokenStore.clear();
      socketRef.current?.disconnect();
      socketRef.current = null;
      setUser(null);
      setRoom(null);
      setRooms([]);
      if (message) notify(message, 'error');
    },
    [notify],
  );

  // เชื่อมต่อ socket เมื่อเข้าสู่ระบบ
  useEffect(() => {
    if (!user) return;
    const socket = io({ auth: { token: tokenStore.get() }, transports: ['websocket', 'polling'] });
    socketRef.current = socket;
    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on('connect_error', (e) => {
      if (e.message === 'unauthorized') logout('เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่');
    });
    socket.on('me:credits', (c) => setCredits(c.credits));
    socket.on('lobby:rooms', setRooms);
    socket.on('room:state', (st) => setRoom({ ...st, receivedAt: Date.now() }));
    socket.on('room:left', () => setRoom(null));
    socket.on('room:fx', (f) => play(f.name));
    socket.on('session:kicked', (k) => logout(k.reason));
    return () => {
      socket.removeAllListeners();
      socket.disconnect();
    };
  }, [user?.id, logout]);

  const emit = useCallback(
    (event, payload) =>
      new Promise((resolve) => {
        const s = socketRef.current;
        if (!s) return resolve({ ok: false, error: 'ยังไม่ได้เชื่อมต่อเซิร์ฟเวอร์' });
        const timer = setTimeout(() => resolve({ ok: false, error: 'เซิร์ฟเวอร์ไม่ตอบสนอง' }), 8000);
        const cb = (res) => {
          clearTimeout(timer);
          resolve(res || { ok: true });
        };
        if (payload === undefined) s.emit(event, cb);
        else s.emit(event, payload, cb);
      }),
    [],
  );

  if (booting) {
    return (
      <div className="h-full bg-casino flex items-center justify-center text-gold text-xl">
        <span className="animate-pulse">กำลังโหลด…</span>
      </div>
    );
  }

  let page;
  if (!user) {
    page = (
      <AuthPage
        onAuthed={({ token, user: u }) => {
          tokenStore.set(token);
          setUser(u);
          setCredits(u.credits);
        }}
      />
    );
  } else if (room) {
    page = <GamePage room={room} user={user} credits={credits} emit={emit} notify={notify} connected={connected} />;
  } else {
    page = <Lobby user={user} credits={credits} rooms={rooms} emit={emit} notify={notify} onLogout={() => logout()} connected={connected} />;
  }

  return (
    <>
      {page}
      {toast && (
        <div
          key={toast.id}
          className={`pop fixed left-1/2 top-4 z-[100] -translate-x-1/2 rounded-xl px-5 py-3 text-sm font-semibold shadow-2xl ${
            toast.kind === 'error' ? 'bg-red-700 text-white' : 'bg-gold text-black'
          }`}
        >
          {toast.text}
        </div>
      )}
    </>
  );
}

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Html, OrbitControls, Sparkles } from '@react-three/drei';
import * as THREE from 'three';
import { Crown, Coins } from 'lucide-react';
import Card3D from './Card3D.jsx';
import ChipStacks from './Chips3D.jsx';
import { backTexture, CARD_H, CARD_W } from './cardTextures.js';

const RX = 5.3; // รัศมีโต๊ะแกน x
const RZ = 3.35; // รัศมีโต๊ะแกน z
const DECK_POS = [-1.15, 0, -0.05];
const POT_POS = [1.0, 0, 0.0];
const fmt = (n) => Number(n).toLocaleString('th-TH');

// ---------- โต๊ะ ----------
function ellipseShape(rx, rz) {
  const s = new THREE.Shape();
  s.absellipse(0, 0, rx, rz, 0, Math.PI * 2, false, 0);
  return s;
}

function useFeltTexture() {
  return useMemo(() => {
    const c = document.createElement('canvas');
    c.width = c.height = 256;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#808080';
    ctx.fillRect(0, 0, 256, 256);
    const img = ctx.getImageData(0, 0, 256, 256);
    for (let i = 0; i < img.data.length; i += 4) {
      const n = 128 + (Math.random() - 0.5) * 70;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = n;
    }
    ctx.putImageData(img, 0, 0);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(1.6, 1.6);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, []);
}

function useEmblemTexture() {
  return useMemo(() => {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 512;
    const ctx = c.getContext('2d');
    ctx.translate(256, 256);
    ctx.strokeStyle = 'rgba(243,217,122,.55)';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(0, 0, 236, 0, Math.PI * 2);
    ctx.stroke();
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 220, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = 'rgba(243,217,122,.5)';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '700 120px "Noto Sans Thai", Sarabun, sans-serif';
    ctx.fillText('เก้าเก', 0, -10);
    ctx.font = '60px "DejaVu Sans", "Noto Sans Symbols2", sans-serif';
    ctx.fillText('♠  ♥  ♦  ♣', 0, 88);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, []);
}

function TableBody() {
  const felt = useFeltTexture();
  const emblem = useEmblemTexture();
  const rimGeo = useMemo(() => {
    const outer = ellipseShape(RX + 0.55, RZ + 0.55);
    outer.holes.push(ellipseShape(RX, RZ));
    return new THREE.ExtrudeGeometry(outer, { depth: 0.22, curveSegments: 96, bevelEnabled: true, bevelSize: 0.07, bevelThickness: 0.06, bevelSegments: 4 });
  }, []);
  const feltGeo = useMemo(() => new THREE.ShapeGeometry(ellipseShape(RX, RZ), 96), []);
  const bodyGeo = useMemo(
    () => new THREE.ExtrudeGeometry(ellipseShape(RX + 0.5, RZ + 0.5), { depth: 0.7, curveSegments: 96, bevelEnabled: true, bevelSize: 0.1, bevelThickness: 0.1, bevelSegments: 3 }),
    [],
  );
  const goldGeo = useMemo(() => {
    const o = ellipseShape(RX - 0.2, RZ - 0.2);
    o.holes.push(ellipseShape(RX - 0.27, RZ - 0.27));
    return new THREE.ShapeGeometry(o, 128);
  }, []);
  const gold2Geo = useMemo(() => {
    const o = ellipseShape(RX - 0.4, RZ - 0.4);
    o.holes.push(ellipseShape(RX - 0.43, RZ - 0.43));
    return new THREE.ShapeGeometry(o, 128);
  }, []);
  return (
    <group>
      {/* ตัวโต๊ะด้านล่าง */}
      <mesh geometry={bodyGeo} rotation-x={-Math.PI / 2} position={[0, -0.95, 0]} receiveShadow castShadow>
        <meshStandardMaterial color="#2a1608" roughness={0.6} />
      </mesh>
      {/* ขอบไม้ */}
      <mesh geometry={rimGeo} rotation-x={-Math.PI / 2} position={[0, -0.17, 0]} castShadow receiveShadow>
        <meshStandardMaterial color="#5b2f12" roughness={0.38} metalness={0.15} />
      </mesh>
      {/* พรม */}
      <mesh geometry={feltGeo} rotation-x={-Math.PI / 2} position={[0, 0, 0]} receiveShadow>
        <meshStandardMaterial color="#0d6a3b" map={felt} roughness={0.95} />
      </mesh>
      {/* เส้นทอง */}
      <mesh geometry={goldGeo} rotation-x={-Math.PI / 2} position={[0, 0.004, 0]}>
        <meshStandardMaterial color="#d9b13f" metalness={0.85} roughness={0.28} />
      </mesh>
      <mesh geometry={gold2Geo} rotation-x={-Math.PI / 2} position={[0, 0.004, 0]}>
        <meshStandardMaterial color="#d9b13f" metalness={0.85} roughness={0.28} transparent opacity={0.7} />
      </mesh>
      {/* ตราตรงกลาง */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.006, 0.0]}>
        <planeGeometry args={[3.4, 3.4]} />
        <meshBasicMaterial map={emblem} transparent opacity={0.55} depthWrite={false} />
      </mesh>
    </group>
  );
}

function Deck({ shuffling }) {
  const g = useRef();
  const back = useMemo(() => backTexture(), []);
  const t0 = useRef(0);
  useEffect(() => {
    if (shuffling) t0.current = performance.now();
  }, [shuffling]);
  useFrame(() => {
    if (!g.current) return;
    const el = (performance.now() - t0.current) / 1000;
    const k = shuffling && el < 1.4 ? 1 : 0;
    g.current.position.x = DECK_POS[0] + Math.sin(el * 38) * 0.05 * k;
    g.current.rotation.y = Math.sin(el * 26) * 0.12 * k;
  });
  return (
    <group ref={g} position={DECK_POS}>
      <mesh position-y={0.1} castShadow receiveShadow>
        <boxGeometry args={[CARD_W - 0.04, 0.2, CARD_H - 0.04]} />
        <meshStandardMaterial color="#efe9d6" roughness={0.8} />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position-y={0.2015}>
        <planeGeometry args={[CARD_W, CARD_H]} />
        <meshStandardMaterial map={back} transparent alphaTest={0.5} roughness={0.5} />
      </mesh>
    </group>
  );
}

// ---------- กล้อง ----------
function CameraRig() {
  const { camera, size, controls } = useThree();
  useEffect(() => {
    const aspect = size.width / size.height;
    // จอแคบ (มือถือแนวตั้ง) ถอยกล้องออกให้เห็นโต๊ะทั้งใบ
    const s = THREE.MathUtils.clamp(1.9 / aspect, 1, 2.4);
    camera.position.set(0, 9.4 * s, 7.4 * s);
    camera.fov = aspect < 1 ? 46 : 38;
    camera.updateProjectionMatrix();
    controls?.update?.();
  }, [size.width, size.height, camera, controls]);
  return null;
}

// ---------- ตำแหน่งที่นั่ง ----------
function makeSeatLayout(room, myUid) {
  const N = room.settings.maxPlayers;
  const me = room.players.find((p) => p.userId === myUid);
  const mySeat = me?.seat ?? 0;
  return (seat) => {
    const rel = (seat - mySeat + N) % N;
    const a = Math.PI / 2 + (2 * Math.PI * rel) / N;
    const cx = Math.cos(a);
    const sz = Math.sin(a);
    const cardPos = [RX * 0.55 * cx, 0, RZ * 0.55 * sz];
    const plate = [RX * 0.88 * cx, 0.05, RZ * 0.86 * sz];
    const dx = -cardPos[0];
    const dz = -cardPos[2];
    const len = Math.hypot(dx, dz) || 1;
    const d = [dx / len, dz / len];
    return { a, cardPos, plate, yaw: Math.atan2(-d[0], -d[1]), tangent: [-d[1], d[0]], bet: [cardPos[0] * 0.5 + d[0] * 0.0, 0, cardPos[2] * 0.5] };
  };
}

// ---------- การนับเวลา ----------
export function useCountdown(room) {
  const [left, setLeft] = useState(null);
  useEffect(() => {
    if (!room.turnEndsAt) return setLeft(null);
    const skew = room.receivedAt - room.serverNow;
    const tick = () => setLeft(Math.max(0, (room.turnEndsAt + skew - Date.now()) / 1000));
    tick();
    const id = setInterval(tick, 100);
    return () => clearInterval(id);
  }, [room.turnEndsAt, room.receivedAt, room.serverNow]);
  return left;
}

function TurnTimerBar({ room }) {
  const left = useCountdown(room);
  if (left === null) return null;
  const pct = Math.min(100, (left / room.settings.turnTime) * 100);
  return (
    <div className="mt-1">
      <div className="h-1.5 overflow-hidden rounded-full bg-white/15">
        <div className={`h-full ${left < 5 ? 'bg-red-400' : 'bg-gold-light'}`} style={{ width: `${pct}%`, transition: 'width .1s linear' }} />
      </div>
      <div className={`text-[11px] font-bold ${left < 5 ? 'text-red-300' : 'text-gold-light'}`}>{Math.ceil(left)} วิ</div>
    </div>
  );
}

function statusOf(p, room) {
  if (p.left) return ['ออกจากโต๊ะ', 'text-white/50'];
  if (!p.online) return ['หลุดการเชื่อมต่อ', 'text-red-300'];
  if (p.folded) return ['หมอบ', 'text-red-300'];
  if (p.inHand) return ['เล่นอยู่', 'text-emerald-300'];
  if (p.sittingOut) return [p.credits < room.settings.ante ? 'เครดิตไม่พอ' : 'รอตาถัดไป', 'text-amber-300'];
  return ['พร้อม', 'text-white/70'];
}

function SeatPlate({ p, room, isMe, isTurn, isWinner }) {
  const [status, cls] = statusOf(p, room);
  const delta = room.result?.deltas?.[p.userId];
  return (
    <div className="relative flex flex-col items-center" style={{ pointerEvents: 'none' }}>
      {p.lastAction && ['bet1', 'bet2', 'draw'].includes(room.phase) && (
        <div key={p.lastAction + room.phase} className="pop mb-1 whitespace-nowrap rounded-full bg-gold px-2 py-0.5 text-[11px] font-extrabold text-black shadow">
          {p.lastAction}
        </div>
      )}
      {room.phase === 'result' && delta !== undefined && (
        <div
          className={`float-up absolute -top-7 text-lg font-black drop-shadow ${delta >= 0 ? 'text-emerald-300' : 'text-red-300'}`}
          style={{ textShadow: '0 2px 6px #000' }}
        >
          {delta >= 0 ? '+' : ''}
          {fmt(delta)}
        </div>
      )}
      <div
        className={`w-[132px] rounded-xl border px-2 py-1 text-center backdrop-blur transition ${
          isTurn ? 'pulse-gold border-gold-light bg-black/80' : isWinner ? 'border-gold-light bg-gold/25' : 'border-white/20 bg-black/60'
        } ${p.folded || p.left ? 'opacity-65' : ''}`}
      >
        <div className="flex items-center justify-center gap-1 text-[13px] font-extrabold leading-tight">
          {p.isOwner && <Crown size={12} className="text-gold-light" />}
          <span className="max-w-[96px] truncate">{p.name}</span>
          {isMe && <span className="rounded bg-gold px-1 text-[9px] text-black">คุณ</span>}
        </div>
        <div className="flex items-center justify-center gap-1 text-[12px] font-bold text-gold-light">
          <Coins size={11} /> {fmt(p.credits)}
        </div>
        <div className={`text-[11px] font-semibold ${cls}`}>
          {status}
          {p.handLabel ? <span className="ml-1 text-gold-light">· {p.handLabel}</span> : null}
        </div>
        {p.inHand && p.contrib > 0 && <div className="text-[10px] text-white/55">ลงไป {fmt(p.contrib)}</div>}
        {isTurn && <TurnTimerBar room={room} />}
      </div>
    </div>
  );
}

function GoldRing({ pos, yaw, state }) {
  const m = useRef();
  const g = useRef();
  useFrame(({ clock }) => {
    if (!m.current) return;
    const t = clock.getElapsedTime();
    if (state === 'turn') {
      m.current.opacity = 0.75 + Math.sin(t * 5) * 0.25;
      g.current.scale.setScalar(1 + Math.sin(t * 5) * 0.025);
    } else {
      m.current.opacity = state === 'win' ? 0.95 : 0.14;
      g.current.scale.setScalar(1);
    }
  });
  const color = state === 'turn' || state === 'win' ? '#ffd24a' : '#ffffff';
  return (
    <group ref={g} position={[pos[0], 0.012, pos[2]]} rotation-y={yaw}>
      <mesh rotation-x={-Math.PI / 2} scale={[1.75, 1.18, 1]}>
        <ringGeometry args={[0.93, 1.0, 64]} />
        <meshBasicMaterial ref={m} color={color} transparent opacity={0.15} depthWrite={false} />
      </mesh>
      {(state === 'turn' || state === 'win') && (
        <mesh rotation-x={-Math.PI / 2} scale={[1.75, 1.18, 1]}>
          <ringGeometry args={[0.82, 0.93, 64]} />
          <meshBasicMaterial color={color} transparent opacity={0.1} depthWrite={false} />
        </mesh>
      )}
    </group>
  );
}

function Scene({ room, myUid, peeked, onPeek }) {
  const layout = useMemo(() => makeSeatLayout(room, myUid), [room.settings.maxPlayers, room.players.find((p) => p.userId === myUid)?.seat]);
  const players = room.players;
  const inHand = players.filter((p) => p.inHand).sort((a, b) => a.seat - b.seat);
  const shuffling = room.phase === 'dealing';
  const revealed = room.phase === 'result' && !room.result?.byFold;

  return (
    <>
      <color attach="background" args={['#050f0a']} />
      <fog attach="fog" args={['#050f0a', 18, 40]} />
      <ambientLight intensity={0.55} />
      <hemisphereLight args={['#cfeedd', '#06130d', 0.4]} />
      <directionalLight
        position={[4, 11, 6]}
        intensity={1.5}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-9}
        shadow-camera-right={9}
        shadow-camera-top={9}
        shadow-camera-bottom={-9}
        shadow-bias={-0.0004}
      />
      <spotLight position={[0, 8.5, 0.5]} angle={0.85} penumbra={1} intensity={110} color="#ffe9b3" distance={24} decay={2} />
      <pointLight position={[-6, 3, 4]} intensity={8} color="#ffcf8a" distance={14} />
      <pointLight position={[6, 3, -4]} intensity={6} color="#9ad4ff" distance={14} />

      <mesh rotation-x={-Math.PI / 2} position-y={-1.3} receiveShadow>
        <circleGeometry args={[40, 64]} />
        <meshStandardMaterial color="#07130d" roughness={1} />
      </mesh>

      <TableBody />
      <Deck shuffling={shuffling} />

      {/* หม้อกลาง */}
      <ChipStacks amount={room.pot} position={POT_POS} scale={1} />
      {room.pot > 0 && (
        <Html position={[POT_POS[0], 0.9, POT_POS[2] + 0.55]} center zIndexRange={[20, 0]} style={{ pointerEvents: 'none' }}>
          <div className="whitespace-nowrap rounded-full border border-gold bg-black/75 px-3 py-0.5 text-sm font-extrabold text-gold-light shadow">
            หม้อ {fmt(room.pot)}
          </div>
        </Html>
      )}

      {/* ที่นั่ง */}
      {Array.from({ length: room.settings.maxPlayers }).map((_, seat) => {
        const L = layout(seat);
        const p = players.find((x) => x.seat === seat);
        if (!p) {
          return (
            <Html key={`e${seat}`} position={L.plate} center zIndexRange={[20, 0]} style={{ pointerEvents: 'none' }}>
              <div className="rounded-lg border border-dashed border-white/25 px-3 py-1 text-[11px] text-white/35">ที่นั่งว่าง</div>
            </Html>
          );
        }
        const isTurn = room.turnUid === p.userId;
        const isWinner = room.phase === 'result' && room.result?.winnerUid === p.userId;
        return (
          <group key={p.userId}>
            {p.inHand && <GoldRing pos={L.cardPos} yaw={L.yaw} state={isTurn ? 'turn' : isWinner ? 'win' : 'idle'} />}
            <Html position={L.plate} center zIndexRange={[20, 0]} style={{ pointerEvents: 'none' }}>
              <SeatPlate p={p} room={room} isMe={p.userId === myUid} isTurn={isTurn} isWinner={isWinner} />
            </Html>
            {p.roundBet > 0 && ['bet1', 'bet2'].includes(room.phase) && <ChipStacks amount={p.roundBet} position={L.bet} scale={0.55} />}
            {isWinner && <Sparkles count={60} scale={[3.4, 1.4, 2.4]} size={7} speed={0.9} color="#ffd35a" position={[L.cardPos[0], 0.7, L.cardPos[2]]} />}
          </group>
        );
      })}

      {/* ไพ่ */}
      {inHand.map((p, pi) => {
        const L = layout(p.seat);
        const n = p.cardCount;
        const isMe = p.userId === myUid;
        const show = revealed && p.handLabel != null && p.cards;
        return Array.from({ length: n }).map((_, i) => {
          const off = (i - (n - 1) / 2) * 0.56;
          const cardData = show || isMe ? p.cards?.[i] ?? null : null;
          let mode = 'down';
          if (show) mode = 'up';
          else if (isMe && peeked.has(i)) mode = 'peek';
          const third = i === 2;
          const delay = third ? 0.15 + pi * 0.28 : 0.55 + (i * inHand.length + pi) * 0.24;
          return (
            <Card3D
              key={`${room.handNo}-${p.userId}-${i}`}
              card={cardData}
              dim={p.folded}
              delay={delay}
              startPos={[DECK_POS[0], 0.35, DECK_POS[2]]}
              target={{
                x: L.cardPos[0] + L.tangent[0] * off,
                z: L.cardPos[2] + L.tangent[1] * off,
                y: 0.02 + i * 0.016,
                yaw: L.yaw + (i - (n - 1) / 2) * -0.06,
                mode,
              }}
              interactive={isMe}
              onClick={() => onPeek(i)}
            />
          );
        });
      })}

      <OrbitControls
        makeDefault
        target={[0, 0, 0.9]}
        enablePan={false}
        enableDamping
        minDistance={7}
        maxDistance={22}
        minPolarAngle={0.35}
        maxPolarAngle={1.12}
        minAzimuthAngle={-0.5}
        maxAzimuthAngle={0.5}
      />
      <CameraRig />
    </>
  );
}

export default function Table3D({ room, myUid, peeked, onPeek }) {
  return (
    <Canvas shadows dpr={[1, 2]} camera={{ position: [0, 9.4, 7.4], fov: 38, near: 0.1, far: 80 }} gl={{ antialias: true, preserveDrawingBuffer: true }}>
      <Scene room={room} myUid={myUid} peeked={peeked} onPeek={onPeek} />
    </Canvas>
  );
}

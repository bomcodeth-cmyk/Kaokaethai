"""E2E: ผู้เล่น 3 คนในเบราว์เซอร์จริง สร้างโต๊ะ เล่น และถ่ายภาพหน้าจอ"""
import asyncio, sys, json
from playwright.async_api import async_playwright

BASE = 'http://localhost:3001'
OUT = '/home/ubuntu/shots'

async def main():
    import os
    os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        pages = {}
        for name in ['somchai', 'malee', 'prasit']:
            ctx = await b.new_context(viewport={'width': 1360, 'height': 800}, locale='th-TH')
            pg = await ctx.new_page()
            pg.on('console', lambda m, n=name: print(f'[{n}] console.{m.type}: {m.text}') if m.type in ('error', 'warning') else None)
            pg.on('pageerror', lambda e, n=name: print(f'[{n}] PAGEERROR: {e}'))
            pages[name] = pg
            await pg.goto(BASE)
            await pg.wait_for_selector('input[autocomplete="username"]')
            if name == 'somchai':
                await pg.screenshot(path=f'{OUT}/01_login.png')
            await pg.click('text=สมัครสมาชิก >> nth=0')
            await pg.fill('input[autocomplete="username"]', name)
            await pg.fill('input[autocomplete="new-password"]', 'secret123')
            await pg.click('button:has-text("สมัครและรับเครดิตเริ่มต้น")')
            await pg.wait_for_selector('[data-testid=credits]')
        print('registered; credits =', await pages['somchai'].inner_text('[data-testid=credits]'))
        a = pages['somchai']
        await a.click('button:has-text("สร้างโต๊ะ") >> nth=0')
        await a.wait_for_selector('text=สร้างโต๊ะใหม่')
        await a.screenshot(path=f'{OUT}/02_create.png')
        await a.click('button:has-text("ตกลง")') if False else None
        await a.click('.panel button:has-text("สร้างโต๊ะ") >> nth=-1')
        await a.wait_for_selector('text=รอผู้เล่น')
        code = (await a.inner_text('b.font-mono')).strip()
        print('room code', code)
        for n in ['malee', 'prasit']:
            await pages[n].wait_for_selector('[data-testid=room-card]')
            if n == 'malee':
                await pages[n].screenshot(path=f'{OUT}/03_lobby.png')
            await pages[n].fill('[data-testid=code-input]', code)
            await pages[n].click('button:has-text("เข้า") >> nth=-1')
            await pages[n].wait_for_selector('text=รอเจ้าของโต๊ะ')
        await a.click('button:has-text("เริ่มเกม")')
        await a.wait_for_timeout(1500)
        await a.screenshot(path=f'{OUT}/04_dealing.png')
        await a.wait_for_timeout(4500)
        await a.screenshot(path=f'{OUT}/05_bet1.png')
        # ให้ทุกคนที่ถึงตาเล่น (somchai เก, คนอื่นสู้)
        async def play_turn(max_loops=40):
            for _ in range(max_loops):
                for n, pg in pages.items():
                    if await pg.locator('[data-testid=action-bar]').count():
                        return n, pg
                await asyncio.sleep(0.25)
            return None, None
        n, pg = await play_turn()
        print('first actor', n)
        await pg.click('canvas', position={'x': 680, 'y': 560})  # คลิกไพ่ (แง้ม)
        await pg.wait_for_timeout(1200)
        await pg.screenshot(path=f'{OUT}/06_peek_{n}.png')
        await pg.click('[data-testid=btn-raise]')
        await asyncio.sleep(0.8)
        for step in range(30):
            n, pg = await play_turn(8)
            if not n:
                # หมดตา? ตรวจผล
                if await a.locator('[data-testid=winner-banner]').count():
                    break
                continue
            if step == 2:
                await pg.screenshot(path=f'{OUT}/07_turn_{n}.png')
            await pg.click('[data-testid=btn-call]')
            await asyncio.sleep(1.0)
        await a.wait_for_selector('[data-testid=winner-banner]', timeout=30000)
        await a.wait_for_timeout(1800)
        await a.screenshot(path=f'{OUT}/08_result.png')
        print('winner banner:', (await a.inner_text('[data-testid=winner-banner]')).replace('\n', ' | '))
        print('credits after:', {n: await pg.inner_text('[data-testid=credits]') for n, pg in pages.items()})
        await b.close()

asyncio.run(main())

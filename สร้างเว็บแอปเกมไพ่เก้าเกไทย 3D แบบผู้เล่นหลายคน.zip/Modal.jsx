import React, { useEffect } from 'react';
import { X } from 'lucide-react';

export default function Modal({ title, onClose, children, wide = false }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onMouseDown={onClose}>
      <div
        className={`panel pop max-h-[90vh] w-full overflow-auto scroll-thin bg-[#0a2417] p-5 ${wide ? 'max-w-2xl' : 'max-w-md'}`}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-extrabold text-gold-light">{title}</h2>
          <button className="rounded-lg p-1 text-white/60 hover:bg-white/10 hover:text-white" onClick={onClose} aria-label="ปิด">
            <X size={20} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

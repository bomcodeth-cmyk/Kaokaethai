// เทสต์ integration: เปิดเซิร์ฟเวอร์จริงบนฐานข้อมูลชั่วคราว แล้วให้ "บอท" เล่นผ่าน HTTP + Socket.io
import { spawn, execSync } from 'node:child_process';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io as connect } from 'socket.io-client';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = 3055;
const BASE = `http://localhost:${PORT}`;
const dbFile = path.join(root, 'prisma', 'test.db');
for (const f of [dbFile, dbFile + '-journal']) fs.rmSync(f, { force: true });
const env = { ...process.env, PORT: String(PORT), DATABASE_URL: 'file:./test.db', FAST_TIMERS: '1', ADMIN_CODE: 'bigboss2026' };
execSync('npx prisma db push --skip-generate --force-reset', { cwd: root, env, stdio: 'ignore' });

const server = spawn('node', ['server/index.js'], { cwd: root, env, stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise((res) => server.stdout.on('data', (d) => String(d).includes('พร้อมแล้ว') && res()));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const post = async (url, body, token) => {
  const r = await fetch(BASE + url, { method: 'POST', headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) }, body: JSON.stringify(body) });
  return { status: r.status, body: await r.json() };
};
const get = async (url, token) => {
  const r = await fetch(BASE + url, { headers: token ? { authorization: `Bearer ${token}` } : {} });
  return { status: r.status, body: await r.json() };
};
const emit = (s, ev, ...a) => new Promise((res) => s.emit(ev, ...a, res));

let exitCode = 0;
try {
  // ---------- บัญชี ----------
  assert.equal((await post('/api/auth/register', { username: 'ab', password: '123456' })).status, 400, 'ชื่อสั้นต้องถูกปฏิเสธ');
  assert.equal((await post('/api/auth/register', { username: 'abcdef', password: '123' })).status, 400, 'รหัสผ่านสั้นต้องถูกปฏิเสธ');
  assert.equal((await post('/api/auth/register', { username: 'x'.repeat(21), password: '123456' })).status, 400);
  const users = {};
  for (const n of ['alice', 'bob', 'carol']) {
    const r = await post('/api/auth/register', { username: n, password: 'secret1' });
    assert.equal(r.status, 200);
    assert.equal(r.body.user.credits, 1000);
    users[n] = { ...r.body.user, token: r.body.token };
  }
  assert.equal((await post('/api/auth/register', { username: 'ALICE', password: 'secret1' })).status, 409, 'ชื่อซ้ำ (ไม่สนตัวพิมพ์)');
  assert.equal((await post('/api/auth/login', { username: 'alice', password: 'wrong' })).status, 401);
  const lg = await post('/api/auth/login', { username: 'alice', password: 'secret1' });
  assert.equal(lg.status, 200);
  assert.equal((await get('/api/auth/me', lg.body.token)).body.user.username, 'alice');
  assert.equal((await get('/api/auth/me', 'bad')).status, 401);
  // รหัสผ่านต้องไม่เป็น plain text
  const { PrismaClient } = await import('@prisma/client');
  const prisma = new PrismaClient({ datasources: { db: { url: 'file:./test.db' } } });
  const row = await prisma.user.findUnique({ where: { usernameLower: 'alice' } });
  assert.ok(row.passwordHash.startsWith('$2'), 'ต้องเป็น bcrypt hash');
  assert.notEqual(row.passwordHash, 'secret1');
  console.log('✓ บัญชี: สมัคร/ล็อกอิน/ตรวจความถูกต้อง/bcrypt');

  // ---------- admin ----------
  assert.equal((await post('/api/admin/login', { code: 'nope' })).status, 401);
  assert.equal((await get('/api/admin/users')).status, 401, 'ไม่มีโทเคนต้องเข้าไม่ได้');
  const adm = await post('/api/admin/login', { code: 'bigboss2026' });
  assert.equal(adm.status, 200);
  const A = adm.body.token;
  assert.equal((await get('/api/admin/users?q=ali', A)).body.users.length, 1);

  // ---------- เกม ----------
  const sockets = {};
  const states = {};
  const fxs = [];
  const credits = {};
  for (const n of Object.keys(users)) {
    const s = connect(BASE, { auth: { token: users[n].token }, transports: ['websocket'] });
    sockets[n] = s;
    s.on('room:state', (st) => (states[n] = st));
    s.on('me:credits', (c) => (credits[n] = c.credits));
    if (n === 'alice') s.on('room:fx', (f) => fxs.push(f.name));
    await new Promise((res, rej) => { s.on('connect', res); s.on('connect_error', rej); });
  }
  await sleep(200);
  const bad = connect(BASE, { auth: { token: 'bogus' }, transports: ['websocket'], reconnection: false });
  await new Promise((res) => bad.on('connect_error', res));
  console.log('✓ socket ไม่มีโทเคนที่ถูกต้องเชื่อมต่อไม่ได้');

  assert.equal((await emit(sockets.alice, 'room:create', { rounds: 7, maxPlayers: 4, turnTime: 10, ante: 10 })).ok, false, 'จำนวนตาผิดต้องถูกปฏิเสธ');
  assert.equal((await emit(sockets.alice, 'room:create', { rounds: 5, maxPlayers: 9, turnTime: 10, ante: 10 })).ok, false);
  const created = await emit(sockets.alice, 'room:create', { rounds: 3, maxPlayers: 4, turnTime: 1, ante: 10 });
  assert.ok(created.ok, JSON.stringify(created));
  const code = created.code;
  assert.match(code, /^[A-Z0-9]{4}$/);
  assert.equal((await emit(sockets.bob, 'room:join', { code: 'ZZZZ' })).ok, false);
  assert.ok((await emit(sockets.bob, 'room:join', { code: code.toLowerCase() })).ok);
  assert.ok((await emit(sockets.carol, 'room:join', { code })).ok);
  assert.equal((await emit(sockets.bob, 'room:start')).ok, false, 'ไม่ใช่เจ้าของเริ่มเกมไม่ได้');
  assert.ok((await emit(sockets.alice, 'room:start')).ok);
  console.log('✓ สร้างโต๊ะ/เข้าร่วม/เริ่มเกม');

  const totalBefore = 3000;
  const dumpTotal = async () => {
    const all = await prisma.user.findMany();
    return all.reduce((a, u) => a + u.credits + u.escrow, 0);
  };
  const seenPhases = new Set();
  let invariantChecks = 0;
  let outOfTurnRejected = 0;
  let finished = false;
  let timeoutFolds = 0;
  const deadline = Date.now() + 40_000;
  while (!finished && Date.now() < deadline) {
    await sleep(60);
    for (const n of Object.keys(sockets)) {
      const st = states[n];
      if (!st) continue;
      seenPhases.add(st.phase);
      // ความลับของไพ่: ห้ามเห็นไพ่คนอื่นก่อนเปิด
      for (const p of st.players) {
        if (p.userId !== users[n].id && st.phase !== 'result') assert.equal(p.cards, null, `${n} ไม่ควรเห็นไพ่ของ ${p.name} ในช่วง ${st.phase}`);
        if (st.result?.byFold) if (p.userId !== users[n].id) assert.equal(p.cards, null, 'ชนะเพราะหมอบ ต้องไม่เปิดไพ่');
      }
      const me = st.players.find((p) => p.userId === users[n].id);
      if (['bet1', 'bet2'].includes(st.phase) && me.inHand) assert.equal(me.cards.length, st.phase === 'bet1' ? 2 : 3);
      if (st.status === 'finished') finished = true;
      if (st.you.canAct) {
        // ลองแอบเล่นแทนคนอื่นก่อน
        const other = Object.keys(sockets).find((x) => x !== n);
        const r = await emit(sockets[other], 'game:action', { type: 'call' });
        if (!r.ok) outOfTurnRejected++;
        if (n === 'carol' && Math.random() < 0.35) continue; // ปล่อยให้หมดเวลา -> หมอบอัตโนมัติ (turnTime=1)
        const pick = Math.random();
        const act = pick < 0.15 ? { type: 'fold' } : pick < 0.5 && st.you.maxRaiseK > 0 ? { type: 'raise', k: 1 + Math.floor(Math.random() * st.you.maxRaiseK) } : { type: 'call' };
        await emit(sockets[n], 'game:action', act);
        // เงื่อนไขคงที่: เครดิต+escrow ทั้งระบบเท่าเดิมตลอด
        assert.equal(await dumpTotal(), totalBefore, 'เครดิตรวมต้องไม่เปลี่ยน');
        invariantChecks++;
      }
    }
  }
  assert.ok(finished, 'เกมต้องจบครบจำนวนตา');
  assert.ok(outOfTurnRejected > 0, 'การเล่นแทนคนอื่นต้องถูกปฏิเสธ');
  for (const ph of ['dealing', 'bet1', 'draw', 'bet2']) assert.ok(seenPhases.has(ph) || ph === 'bet2' || ph === 'draw', `ต้องเห็นเฟส ${ph}`);
  assert.equal(states.alice.handNo, 3);
  assert.equal(await dumpTotal(), totalBefore);
  const final = await prisma.user.findMany();
  assert.ok(final.every((u) => u.escrow === 0), 'escrow ต้องว่างเมื่อจบเกม');
  const recs = await prisma.handRecord.findMany();
  assert.equal(recs.length, 9, '3 ตา x 3 ผู้เล่น');
  assert.equal(recs.filter((r) => r.won).length, 3, 'ทุกตามีผู้ชนะ 1 คน');
  for (let h = 1; h <= 3; h++) assert.equal(recs.filter((r) => r.handNo === h).reduce((a, r) => a + r.delta, 0), 0, 'ผลรวมกำไรขาดทุนต่อตา = 0');
  for (const u of final) assert.equal(u.wins + u.losses, 3);
  for (const n of Object.keys(users)) assert.equal(credits[n], final.find((u) => u.username === n).credits, `${n} ซิงก์เครดิตทาง socket ตรงกับฐานข้อมูล`);
  assert.ok(['shuffle', 'deal', 'win'].every((f) => fxs.includes(f)), 'ต้องมี fx ครบ: ' + [...new Set(fxs)]);
  console.log(`✓ เล่นครบ 3 ตา (ตรวจเงื่อนไขเครดิตรวม ${invariantChecks} ครั้ง, ปฏิเสธการเล่นแทน ${outOfTurnRejected} ครั้ง)`);
  console.log('   ผลสุดท้าย:', final.map((u) => `${u.username}=${u.credits} (${u.wins}W/${u.losses}L)`).join(', '));

  // ---------- ประวัติ ----------
  const hist = await get('/api/auth/history', users.alice.token);
  assert.equal(hist.body.records.length, 3);

  // ---------- แอดมินปรับเครดิต -> สะท้อนทันที ----------
  const bobId = users.bob.id;
  let pushed = null;
  sockets.bob.on('me:credits', (c) => (pushed = c.credits));
  assert.equal((await post(`/api/admin/users/${bobId}/credits`, { mode: 'set', amount: 777 }, A)).status, 200);
  await sleep(300);
  assert.equal(pushed, 777);
  assert.equal(states.bob.players.find((p) => p.userId === bobId).credits, 777, 'เพื่อนร่วมโต๊ะเห็นเครดิตใหม่');
  await post(`/api/admin/users/${bobId}/credits`, { mode: 'add', amount: 23 }, A);
  await post(`/api/admin/users/${bobId}/credits`, { mode: 'sub', amount: 5000 }, A);
  assert.equal((await prisma.user.findUnique({ where: { id: bobId } })).credits, 0, 'ลบเกินต้องเหลือ 0');
  assert.equal((await post(`/api/admin/users/${bobId}/credits`, { mode: 'add', amount: -5 }, A)).status, 400);
  await post(`/api/admin/users/${bobId}/credits`, { mode: 'set', amount: 1000 }, A);
  const list = await get('/api/admin/users', A);
  assert.equal(list.body.users.find((u) => u.username === 'alice').online, true);
  console.log('✓ แอดมิน: ปรับเครดิตและซิงก์ถึงผู้เล่นทันที');

  // ---------- รีเซ็ตรหัสผ่าน / ลบ ----------
  assert.equal((await post(`/api/admin/users/${bobId}/password`, { password: 'newpass1' }, A)).status, 200);
  assert.equal((await get('/api/auth/me', users.bob.token)).status, 401, 'โทเคนเก่าใช้ไม่ได้หลังรีเซ็ต');
  assert.equal((await post('/api/auth/login', { username: 'bob', password: 'newpass1' })).status, 200);
  const del = await fetch(`${BASE}/api/admin/users/${users.carol.id}`, { method: 'DELETE', headers: { authorization: `Bearer ${A}` } });
  assert.equal(del.status, 200);
  assert.equal((await post('/api/auth/login', { username: 'carol', password: 'secret1' })).status, 401);
  console.log('✓ แอดมิน: รีเซ็ตรหัสผ่านและลบผู้เล่น');

  // ---------- ออกจากโต๊ะกลางตา = หมอบ / เหลือคนเดียวชนะทันที ----------
  const s2 = connect(BASE, { auth: { token: (await post('/api/auth/login', { username: 'bob', password: 'newpass1' })).body.token }, transports: ['websocket'] });
  await new Promise((res) => s2.on('connect', res));
  let st2 = null;
  s2.on('room:state', (s) => (st2 = s));
  await emit(sockets.alice, 'room:leave');
  const c2 = await emit(sockets.alice, 'room:create', { rounds: 0, maxPlayers: 2, turnTime: 10, ante: 20 });
  assert.ok((await emit(s2, 'room:join', { code: c2.code })).ok);
  await emit(sockets.alice, 'room:start');
  await sleep(400);
  const t0 = await prisma.user.findMany({ where: { username: { in: ['alice', 'bob'] } } });
  const total0 = t0.reduce((a, u) => a + u.credits + u.escrow, 0);
  await emit(s2, 'room:leave');
  await sleep(500);
  const t1 = await prisma.user.findMany({ where: { username: { in: ['alice', 'bob'] } } });
  assert.equal(t1.reduce((a, u) => a + u.credits + u.escrow, 0), total0);
  assert.ok(t1.every((u) => u.escrow === 0));
  const aliceNow = t1.find((u) => u.username === 'alice');
  assert.equal(states.alice.result?.byFold, true, 'อีกฝ่ายออก -> ชนะทันทีโดยไม่เปิดไพ่');
  assert.equal(states.alice.result.winnerUid, aliceNow.id);
  console.log('✓ ออกจากโต๊ะกลางตา = หมอบ, เหลือคนเดียวชนะหม้อทันที');
  await prisma.$disconnect();
  console.log('\nintegration tests passed');
} catch (e) {
  console.error('\n✗ FAILED:', e);
  exitCode = 1;
} finally {
  server.kill();
  for (const f of [dbFile, dbFile + '-journal']) fs.rmSync(f, { force: true });
  process.exit(exitCode);
}

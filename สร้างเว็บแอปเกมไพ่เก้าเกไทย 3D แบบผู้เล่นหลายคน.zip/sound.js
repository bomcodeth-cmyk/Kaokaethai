// เสียงประกอบสังเคราะห์ด้วย WebAudio (ไม่ต้องมีไฟล์เสียง)
let ctx = null;
let master = null;
let muted = localStorage.getItem('kaokae_muted') === '1';
let noiseBuf = null;

function ensure() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.7;
    master.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

// เบราว์เซอร์ต้องมีการโต้ตอบก่อนจึงจะเล่นเสียงได้
if (typeof window !== 'undefined') {
  const unlock = () => ensure();
  window.addEventListener('pointerdown', unlock, { once: true });
  window.addEventListener('keydown', unlock, { once: true });
}

function noise(t, dur, { freq = 3000, q = 0.8, gain = 0.4, type = 'bandpass', sweep = 0 } = {}) {
  const src = ctx.createBufferSource();
  src.buffer = noiseBuf;
  src.playbackRate.value = 0.8 + Math.random() * 0.4;
  const f = ctx.createBiquadFilter();
  f.type = type;
  f.frequency.setValueAtTime(freq, t);
  if (sweep) f.frequency.exponentialRampToValueAtTime(Math.max(80, freq + sweep), t + dur);
  f.Q.value = q;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(gain, t + 0.005);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  src.connect(f).connect(g).connect(master);
  src.start(t, Math.random() * 0.5, dur + 0.05);
}

function tone(t, freq, dur, { type = 'sine', gain = 0.25, slide = 0 } = {}) {
  const o = ctx.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(gain, t + 0.008);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(g).connect(master);
  o.start(t);
  o.stop(t + dur + 0.05);
}

const sounds = {
  // สับไพ่: ลำดับเสียงซู่สั้น ๆ ถี่ ๆ
  shuffle(t) {
    for (let i = 0; i < 14; i++) noise(t + i * 0.075 + Math.random() * 0.02, 0.07, { freq: 2500 + Math.random() * 3000, q: 0.7, gain: 0.22 });
    for (let i = 0; i < 6; i++) noise(t + 1.1 + i * 0.05, 0.06, { freq: 1800 + Math.random() * 1500, q: 0.9, gain: 0.18 });
  },
  // แจกไพ่: เสียงปาดไพ่ตามจำนวนใบ
  deal(t) {
    for (let i = 0; i < 6; i++) noise(t + i * 0.2, 0.11, { freq: 4200, q: 0.6, gain: 0.35, sweep: -2200 });
  },
  // ชิปกระทบ: เสียงกริ๊กโลหะ/เซรามิก
  chip(t) {
    for (let i = 0; i < 3; i++) {
      const tt = t + i * 0.055;
      tone(tt, 2300 + Math.random() * 400, 0.09, { type: 'triangle', gain: 0.16 });
      tone(tt, 3700, 0.05, { type: 'square', gain: 0.04 });
      noise(tt, 0.03, { freq: 6000, q: 1.2, gain: 0.18 });
    }
  },
  check(t) {
    noise(t, 0.05, { freq: 900, q: 1.5, gain: 0.35 });
    noise(t + 0.1, 0.05, { freq: 900, q: 1.5, gain: 0.3 });
  },
  fold(t) {
    noise(t, 0.18, { freq: 2200, q: 0.5, gain: 0.3, sweep: -1500 });
  },
  tick(t) {
    tone(t, 1250, 0.05, { type: 'square', gain: 0.1 });
  },
  tock(t) {
    tone(t, 880, 0.07, { type: 'square', gain: 0.14 });
  },
  reveal(t) {
    noise(t, 0.22, { freq: 3000, q: 0.5, gain: 0.35, sweep: 2500 });
    tone(t + 0.1, 520, 0.2, { type: 'triangle', gain: 0.15 });
  },
  win(t) {
    [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, i) => {
      tone(t + i * 0.11, f, 0.45, { type: 'triangle', gain: 0.22 });
      tone(t + i * 0.11, f * 2, 0.3, { type: 'sine', gain: 0.07 });
    });
    for (let i = 0; i < 8; i++) tone(t + 0.6 + i * 0.06, 2200 + i * 260, 0.08, { type: 'sine', gain: 0.07 });
  },
  turn(t) {
    tone(t, 740, 0.12, { type: 'sine', gain: 0.2 });
    tone(t + 0.12, 988, 0.18, { type: 'sine', gain: 0.2 });
  },
  join(t) {
    tone(t, 600, 0.1, { type: 'sine', gain: 0.18 });
  },
  click(t) {
    tone(t, 700, 0.04, { type: 'triangle', gain: 0.12 });
  },
};

export function play(name) {
  if (muted) return;
  const c = ensure();
  if (!c || !sounds[name]) return;
  try {
    sounds[name](c.currentTime + 0.01);
  } catch {
    /* ignore */
  }
}

export const isMuted = () => muted;
export function setMuted(m) {
  muted = m;
  localStorage.setItem('kaokae_muted', m ? '1' : '0');
}

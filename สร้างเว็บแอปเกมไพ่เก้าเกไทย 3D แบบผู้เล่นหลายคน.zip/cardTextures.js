// วาดหน้าไพ่จริง 52 ใบ + หลังไพ่ ด้วย Canvas แล้วทำเป็นเทกซ์เจอร์ (cache ไว้)
import * as THREE from 'three';

const W = 256;
const H = 358;
const SUIT = { S: '♠', H: '♥', D: '♦', C: '♣' };
const RED = '#c8102e';
const BLACK = '#151515';
const colorOf = (s) => (s === 'H' || s === 'D' ? RED : BLACK);

const cache = new Map();

function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function toTexture(canvas) {
  const t = new THREE.CanvasTexture(canvas);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

// ตำแหน่งแต้ม (x: 0..1, y: 0..1) ตามเลขไพ่
const L = 0.3;
const M = 0.5;
const R = 0.7;
const PIPS = {
  A: [[M, 0.5]],
  2: [[M, 0.12], [M, 0.88]],
  3: [[M, 0.12], [M, 0.5], [M, 0.88]],
  4: [[L, 0.12], [R, 0.12], [L, 0.88], [R, 0.88]],
  5: [[L, 0.12], [R, 0.12], [M, 0.5], [L, 0.88], [R, 0.88]],
  6: [[L, 0.12], [R, 0.12], [L, 0.5], [R, 0.5], [L, 0.88], [R, 0.88]],
  7: [[L, 0.12], [R, 0.12], [M, 0.31], [L, 0.5], [R, 0.5], [L, 0.88], [R, 0.88]],
  8: [[L, 0.12], [R, 0.12], [M, 0.31], [L, 0.5], [R, 0.5], [M, 0.69], [L, 0.88], [R, 0.88]],
  9: [[L, 0.12], [R, 0.12], [L, 0.37], [R, 0.37], [M, 0.5], [L, 0.63], [R, 0.63], [L, 0.88], [R, 0.88]],
  10: [[L, 0.12], [R, 0.12], [M, 0.25], [L, 0.37], [R, 0.37], [L, 0.63], [R, 0.63], [M, 0.75], [L, 0.88], [R, 0.88]],
};

function drawFront(rank, suit) {
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const ctx = c.getContext('2d');
  const col = colorOf(suit);
  const sym = SUIT[suit];

  // ตัวการ์ด
  rr(ctx, 2, 2, W - 4, H - 4, 20);
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, '#ffffff');
  g.addColorStop(1, '#f1ede0');
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#cfc8b0';
  ctx.stroke();

  // ดัชนีมุม
  const index = (flip) => {
    ctx.save();
    if (flip) {
      ctx.translate(W, H);
      ctx.rotate(Math.PI);
    }
    ctx.fillStyle = col;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = `bold ${rank === '10' ? 40 : 48}px "DejaVu Sans", "Noto Sans", Arial, sans-serif`;
    ctx.fillText(rank, 32, 44);
    ctx.font = '40px "DejaVu Sans", "Noto Sans Symbols2", "Segoe UI Symbol", Arial, sans-serif';
    ctx.fillText(sym, 32, 88);
    ctx.restore();
  };
  index(false);
  index(true);

  const x0 = 62;
  const x1 = W - 62;
  const y0 = 38;
  const y1 = H - 38;
  if (PIPS[rank]) {
    const big = rank === 'A';
    ctx.fillStyle = col;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = `${big ? 150 : 56}px "DejaVu Sans", "Noto Sans Symbols2", "Segoe UI Symbol", Arial, sans-serif`;
    for (const [px, py] of PIPS[rank]) {
      const x = x0 + (x1 - x0) * px;
      const y = y0 + (y1 - y0) * py;
      ctx.save();
      ctx.translate(x, y);
      if (py > 0.5) ctx.rotate(Math.PI);
      ctx.fillText(sym, 0, big ? 6 : 3);
      ctx.restore();
    }
  } else {
    // J Q K: กรอบทองพร้อมตัวอักษรใหญ่
    rr(ctx, 54, 34, W - 108, H - 68, 12);
    const fg = ctx.createLinearGradient(0, 34, 0, H - 34);
    fg.addColorStop(0, '#fff3c4');
    fg.addColorStop(0.5, '#fde9a0');
    fg.addColorStop(1, '#f3d57a');
    ctx.fillStyle = fg;
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = col;
    ctx.stroke();
    rr(ctx, 62, 42, W - 124, H - 84, 8);
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = 'rgba(0,0,0,.35)';
    ctx.stroke();

    ctx.fillStyle = col;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = 'bold 120px "DejaVu Serif", Georgia, "Times New Roman", serif';
    ctx.fillText(rank, W / 2, H / 2 + 2);
    ctx.font = '54px "DejaVu Sans", "Noto Sans Symbols2", "Segoe UI Symbol", Arial, sans-serif';
    ctx.fillText(sym, W / 2, 84);
    ctx.save();
    ctx.translate(W / 2, H - 84);
    ctx.rotate(Math.PI);
    ctx.fillText(sym, 0, 0);
    ctx.restore();
    // มงกุฎ/ลายประดับเล็ก ๆ
    ctx.fillStyle = 'rgba(0,0,0,.12)';
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.arc(W / 2 - 40 + i * 20, 116, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(W / 2 - 40 + i * 20, H - 116, 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  return c;
}

function drawBack() {
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const ctx = c.getContext('2d');
  rr(ctx, 2, 2, W - 4, H - 4, 20);
  ctx.fillStyle = '#f7f3e6';
  ctx.fill();
  rr(ctx, 14, 14, W - 28, H - 28, 12);
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, '#7a0f1f');
  g.addColorStop(1, '#4a0812');
  ctx.fillStyle = g;
  ctx.fill();
  ctx.save();
  rr(ctx, 14, 14, W - 28, H - 28, 12);
  ctx.clip();
  // ลายตารางข้าวหลามตัด
  ctx.strokeStyle = 'rgba(243,217,122,.35)';
  ctx.lineWidth = 1.5;
  for (let i = -H; i < W + H; i += 22) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i + H, H);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(i, H);
    ctx.lineTo(i + H, 0);
    ctx.stroke();
  }
  ctx.restore();
  rr(ctx, 14, 14, W - 28, H - 28, 12);
  ctx.lineWidth = 4;
  ctx.strokeStyle = '#d4af37';
  ctx.stroke();
  rr(ctx, 24, 24, W - 48, H - 48, 8);
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = 'rgba(243,217,122,.7)';
  ctx.stroke();
  // ตราตรงกลาง
  ctx.beginPath();
  ctx.ellipse(W / 2, H / 2, 52, 66, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#4a0812';
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#f3d97a';
  ctx.stroke();
  ctx.fillStyle = '#f3d97a';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '84px "DejaVu Sans", "Noto Sans Symbols2", "Segoe UI Symbol", Arial, sans-serif';
  ctx.fillText('♠', W / 2, H / 2 + 6);
  return c;
}

export function frontTexture(rank, suit) {
  const k = rank + suit;
  if (!cache.has(k)) cache.set(k, toTexture(drawFront(rank, suit)));
  return cache.get(k);
}

export function backTexture() {
  if (!cache.has('back')) cache.set('back', toTexture(drawBack()));
  return cache.get('back');
}

export const CARD_W = 0.8;
export const CARD_H = 1.12;

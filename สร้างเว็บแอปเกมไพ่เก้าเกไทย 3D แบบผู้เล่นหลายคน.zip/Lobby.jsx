import React, { useEffect, useState } from 'react';
import { Coins, History, LogOut, Plus, LogIn, Users, Timer, Hash, Trophy, Layers, Volume2, VolumeX, Wifi, WifiOff } from 'lucide-react';
import Modal from '../components/Modal.jsx';
import { api, tokenStore } from '../lib/api.js';
import { isMuted, play, setMuted } from '../lib/sound.js';

const fmt = (n) => Number(n).toLocaleString('th-TH');

export function TopBar({ user, credits, connected, onLogout, onHistory }) {
  const [muted, setM] = useState(isMuted());
  return (
    <header className="flex flex-wrap items-center justify-between gap-3 border-b border-gold/25 bg-black/30 px-4 py-3 backdrop-blur">
      <div className="flex items-center gap-3">
        <span className="text-2xl font-black text-gold-light">♠ เก้าเกไทย</span>
        <span title={connected ? 'เชื่อมต่อแล้ว' : 'กำลังเชื่อมต่อใหม่'} className={connected ? 'text-emerald-400' : 'text-red-400'}>
          {connected ? <Wifi size={16} /> : <WifiOff size={16} />}
        </span>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <div className="rounded-xl border border-gold/30 bg-black/30 px-3 py-1.5 text-sm">
          <span className="text-white/60">ผู้เล่น </span>
          <b data-testid="username">{user.username}</b>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-gold/40 bg-gold/10 px-3 py-1.5 font-bold text-gold-light" data-testid="credits">
          <Coins size={18} /> {fmt(credits)}
        </div>
        {onHistory && (
          <button className="btn btn-ghost !py-1.5" onClick={onHistory}>
            <History size={16} /> ประวัติ
          </button>
        )}
        <button
          className="btn btn-ghost !px-3 !py-1.5"
          onClick={() => {
            setMuted(!muted);
            setM(!muted);
            play('click');
          }}
          title="เปิด/ปิดเสียง"
        >
          {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </button>
        <button className="btn btn-ghost !py-1.5" onClick={onLogout}>
          <LogOut size={16} /> ออกจากระบบ
        </button>
      </div>
    </header>
  );
}

function CreateTableModal({ onClose, onCreate, credits }) {
  const [rounds, setRounds] = useState(10);
  const [maxPlayers, setMaxPlayers] = useState(4);
  const [turnTime, setTurnTime] = useState(20);
  const [ante, setAnte] = useState(10);
  const [busy, setBusy] = useState(false);
  const need = ante * 5;
  const tooPoor = credits < need;
  return (
    <Modal title="สร้างโต๊ะใหม่" onClose={onClose}>
      <div className="space-y-4">
        <Field label="จำนวนตา">
          {[5, 10, 20, 0].map((r) => (
            <button key={r} className="chip-opt" data-on={rounds === r} onClick={() => setRounds(r)}>
              {r === 0 ? 'ไม่จำกัด' : `${r} ตา`}
            </button>
          ))}
        </Field>
        <Field label={`จำนวนผู้เล่นสูงสุด: ${maxPlayers} คน`}>
          {[2, 3, 4, 5, 6].map((p) => (
            <button key={p} className="chip-opt" data-on={maxPlayers === p} onClick={() => setMaxPlayers(p)}>
              {p}
            </button>
          ))}
        </Field>
        <Field label="เวลาต่อตา (หมดเวลา = หมอบอัตโนมัติ)">
          {[10, 15, 20, 30].map((t) => (
            <button key={t} className="chip-opt" data-on={turnTime === t} onClick={() => setTurnTime(t)}>
              {t} วินาที
            </button>
          ))}
        </Field>
        <div>
          <div className="mb-1 text-sm text-white/70">ค่าต๋งขั้นต่ำ (ลงเข้าหม้อทุกตา)</div>
          <div className="flex flex-wrap items-center gap-2">
            {[10, 50, 100, 500].map((a) => (
              <button key={a} className="chip-opt" data-on={ante === a} onClick={() => setAnte(a)}>
                {a}
              </button>
            ))}
            <input
              className="input !w-28"
              type="number"
              min={5}
              max={1000}
              value={ante}
              onChange={(e) => setAnte(Math.max(0, Math.floor(Number(e.target.value) || 0)))}
            />
          </div>
          <div className={`mt-1 text-xs ${tooPoor ? 'text-red-400' : 'text-white/50'}`}>
            ต้องมีเครดิตอย่างน้อย {fmt(need)} เพื่อนั่งโต๊ะนี้ (ค่าต๋ง x 5) — เกแต่ละครั้งเพิ่มทีละค่าต๋ง
          </div>
        </div>
        <button
          className="btn btn-gold w-full text-lg"
          disabled={busy || tooPoor || ante < 5 || ante > 1000}
          onClick={async () => {
            setBusy(true);
            await onCreate({ rounds, maxPlayers, turnTime, ante });
            setBusy(false);
          }}
        >
          <Plus size={18} /> สร้างโต๊ะ
        </button>
      </div>
    </Modal>
  );
}

const Field = ({ label, children }) => (
  <div>
    <div className="mb-1 text-sm text-white/70">{label}</div>
    <div className="flex flex-wrap gap-2">{children}</div>
  </div>
);

function HistoryModal({ onClose }) {
  const [data, setData] = useState(null);
  useEffect(() => {
    api('/api/auth/history', { token: tokenStore.get() }).then(setData).catch(() => setData({ records: [] }));
  }, []);
  return (
    <Modal title="ประวัติการเล่น" onClose={onClose} wide>
      {!data ? (
        <div className="py-8 text-center text-white/60">กำลังโหลด…</div>
      ) : (
        <>
          <div className="mb-3 grid grid-cols-3 gap-2 text-center">
            <Stat label="ชนะ" value={data.user?.wins ?? 0} color="text-emerald-300" />
            <Stat label="แพ้" value={data.user?.losses ?? 0} color="text-red-300" />
            <Stat label="เครดิต" value={fmt(data.user?.credits ?? 0)} color="text-gold-light" />
          </div>
          <div className="max-h-[50vh] overflow-auto scroll-thin rounded-xl border border-white/10">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-[#0d2d1e] text-white/60">
                <tr>
                  <th className="p-2 text-left">เวลา</th>
                  <th className="p-2 text-left">ห้อง/ตา</th>
                  <th className="p-2 text-left">ผล</th>
                  <th className="p-2 text-right">เครดิต</th>
                </tr>
              </thead>
              <tbody>
                {data.records.length === 0 && (
                  <tr>
                    <td colSpan={4} className="p-6 text-center text-white/50">
                      ยังไม่มีประวัติ ลองสร้างโต๊ะหรือเข้าร่วมเล่นดู
                    </td>
                  </tr>
                )}
                {data.records.map((r) => (
                  <tr key={r.id} className="border-t border-white/5">
                    <td className="p-2 text-white/70">{new Date(r.createdAt).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' })}</td>
                    <td className="p-2">
                      {r.roomCode} · ตา {r.handNo}
                    </td>
                    <td className={`p-2 font-semibold ${r.won ? 'text-emerald-300' : 'text-red-300'}`}>
                      {r.won ? 'ชนะ' : 'แพ้'}
                      {r.byFold && r.won ? ' (ทุกคนหมอบ)' : ''}
                      {r.handLabel ? <span className="ml-1 font-normal text-white/50">· {r.handLabel}</span> : null}
                    </td>
                    <td className={`p-2 text-right font-bold ${r.delta >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>
                      {r.delta >= 0 ? '+' : ''}
                      {fmt(r.delta)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </Modal>
  );
}

const Stat = ({ label, value, color }) => (
  <div className="rounded-xl bg-black/30 p-3">
    <div className="text-xs text-white/50">{label}</div>
    <div className={`text-xl font-extrabold ${color}`}>{value}</div>
  </div>
);

export default function Lobby({ user, credits, rooms, emit, notify, onLogout, connected }) {
  const [creating, setCreating] = useState(false);
  const [history, setHistory] = useState(false);
  const [code, setCode] = useState('');

  const join = async (c) => {
    play('click');
    const r = await emit('room:join', { code: c });
    if (!r.ok) notify(r.error || 'เข้าโต๊ะไม่สำเร็จ', 'error');
  };

  return (
    <div className="bg-casino flex h-full flex-col">
      <TopBar user={user} credits={credits} connected={connected} onLogout={onLogout} onHistory={() => setHistory(true)} />
      <main className="mx-auto grid w-full max-w-6xl flex-1 gap-4 overflow-auto p-4 scroll-thin lg:grid-cols-[1fr_320px]">
        <section className="panel flex min-h-[320px] flex-col p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-xl font-extrabold text-gold-light">
              <Layers size={20} /> โต๊ะที่เปิดอยู่ <span className="text-sm font-normal text-white/50">({rooms.length})</span>
            </h2>
          </div>
          <div className="flex-1 overflow-auto scroll-thin">
            {rooms.length === 0 ? (
              <div className="flex h-full min-h-[200px] flex-col items-center justify-center text-center text-white/50">
                <div className="mb-2 text-5xl">🂠</div>
                ยังไม่มีโต๊ะที่เปิดอยู่
                <br />
                กด “สร้างโต๊ะ” เพื่อเริ่มเกมได้เลย
              </div>
            ) : (
              <div className="grid gap-3 md:grid-cols-2">
                {rooms.map((r) => {
                  const full = r.players >= r.maxPlayers;
                  return (
                    <div key={r.code} className="rounded-xl border border-gold/25 bg-black/30 p-3" data-testid="room-card">
                      <div className="mb-2 flex items-center justify-between">
                        <span className="flex items-center gap-1 font-mono text-2xl font-black tracking-widest text-gold-light">
                          <Hash size={16} className="opacity-60" />
                          {r.code}
                        </span>
                        <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${r.status === 'playing' ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'}`}>
                          {r.status === 'playing' ? 'กำลังเล่น' : r.status === 'finished' ? 'จบเกมแล้ว' : 'รอผู้เล่น'}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm text-white/80">
                        <span>
                          เจ้าของ: <b>{r.owner}</b>
                        </span>
                        <span className="flex items-center gap-1">
                          <Coins size={14} className="text-gold" /> ต๋ง <b>{fmt(r.ante)}</b>
                        </span>
                        <span className="flex items-center gap-1">
                          <Users size={14} /> {r.players}/{r.maxPlayers} คน
                        </span>
                        <span className="flex items-center gap-1">
                          <Timer size={14} /> {r.turnTime} วินาที/ตา
                        </span>
                        <span className="col-span-2 text-white/50">{r.rounds === 0 ? 'ไม่จำกัดตา' : `${r.rounds} ตา`}</span>
                      </div>
                      <button className="btn btn-gold mt-3 w-full !py-2" disabled={full} onClick={() => join(r.code)}>
                        <LogIn size={16} /> {full ? 'โต๊ะเต็ม' : 'เข้าร่วม'}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        <aside className="space-y-4">
          <div className="panel p-4">
            <button className="btn btn-gold w-full text-lg" onClick={() => setCreating(true)}>
              <Plus size={20} /> สร้างโต๊ะ
            </button>
          </div>
          <form
            className="panel p-4"
            onSubmit={(e) => {
              e.preventDefault();
              if (code.length === 4) join(code.toUpperCase());
            }}
          >
            <div className="mb-2 font-bold text-gold-light">เข้าห้องด้วยรหัส 4 ตัวอักษร</div>
            <div className="flex gap-2">
              <input
                className="input text-center font-mono text-xl font-bold uppercase tracking-[.4em]"
                value={code}
                maxLength={4}
                placeholder="ABCD"
                onChange={(e) => setCode(e.target.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase())}
                data-testid="code-input"
              />
              <button className="btn btn-green" disabled={code.length !== 4}>
                เข้า
              </button>
            </div>
          </form>
          <div className="panel p-4">
            <div className="mb-2 flex items-center gap-2 font-bold text-gold-light">
              <Trophy size={18} /> สถิติของคุณ
            </div>
            <div className="grid grid-cols-2 gap-2 text-center">
              <Stat label="ชนะ" value={user.wins ?? 0} color="text-emerald-300" />
              <Stat label="แพ้" value={user.losses ?? 0} color="text-red-300" />
            </div>
            <p className="mt-2 text-xs text-white/40">สถิติและเครดิตถูกบันทึกถาวรในฐานข้อมูล กลับมาเล่นต่อได้เสมอ</p>
          </div>
        </aside>
      </main>

      {creating && (
        <CreateTableModal
          credits={credits}
          onClose={() => setCreating(false)}
          onCreate={async (opts) => {
            const r = await emit('room:create', opts);
            if (!r.ok) notify(r.error || 'สร้างโต๊ะไม่สำเร็จ', 'error');
            else setCreating(false);
          }}
        />
      )}
      {history && <HistoryModal onClose={() => setHistory(false)} />}
    </div>
  );
}

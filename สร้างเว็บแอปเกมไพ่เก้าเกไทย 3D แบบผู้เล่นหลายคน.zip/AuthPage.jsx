import React, { useState } from 'react';
import { Spade, Heart, Diamond, Club, LogIn, UserPlus, ShieldOff } from 'lucide-react';
import { api } from '../lib/api.js';

export default function AuthPage({ onAuthed }) {
  const [mode, setMode] = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const r = await api(`/api/auth/${mode}`, { method: 'POST', body: { username: username.trim(), password } });
      onAuthed(r);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bg-casino h-full overflow-auto flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-6 select-none">
          <div className="flex items-center justify-center gap-3 text-gold mb-2">
            <Spade size={26} /> <Heart size={26} className="text-red-500" /> <Diamond size={26} className="text-red-500" /> <Club size={26} />
          </div>
          <h1 className="text-4xl font-extrabold text-gold-light drop-shadow">เก้าเกไทย</h1>
          <p className="text-gold/80 font-semibold tracking-wide">สองใบจั่วสู้ — ไพ่ไทย 3D ผู้เล่นหลายคน</p>
        </div>

        <form onSubmit={submit} className="panel p-6 space-y-4">
          <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-black/30">
            {[
              ['login', 'เข้าสู่ระบบ', LogIn],
              ['register', 'สมัครสมาชิก', UserPlus],
            ].map(([k, label, Icon]) => (
              <button
                type="button"
                key={k}
                onClick={() => {
                  setMode(k);
                  setError('');
                }}
                className={`btn ${mode === k ? 'btn-gold' : 'text-white/70 hover:text-white'}`}
              >
                <Icon size={16} /> {label}
              </button>
            ))}
          </div>

          <label className="block">
            <span className="text-sm text-white/70">ชื่อผู้ใช้ (3-20 ตัวอักษร)</span>
            <input
              className="input mt-1"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              maxLength={20}
              placeholder="เช่น เสี่ยหมู"
              required
            />
          </label>
          <label className="block">
            <span className="text-sm text-white/70">รหัสผ่าน (อย่างน้อย 6 ตัวอักษร)</span>
            <input
              className="input mt-1"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              placeholder="••••••"
              required
            />
          </label>

          {error && <div className="rounded-lg bg-red-900/60 border border-red-500/50 px-3 py-2 text-sm">{error}</div>}

          <button className="btn btn-gold w-full text-lg" disabled={busy}>
            {busy ? 'กำลังดำเนินการ…' : mode === 'login' ? 'เข้าสู่ระบบ' : 'สมัครและรับเครดิตเริ่มต้น'}
          </button>

          <p className="flex items-center justify-center gap-2 text-xs text-white/50">
            <ShieldOff size={14} /> ไม่ต้องใช้อีเมล ไม่มี OTP ไม่ต้องยืนยันใด ๆ
          </p>
        </form>
      </div>
    </div>
  );
}

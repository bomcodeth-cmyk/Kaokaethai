import React, { useMemo } from 'react';

// มูลค่า -> สี (เรียงจากสูงไปต่ำ)
const DENOMS = [
  [1000, '#7c3aed'],
  [500, '#d4af37'],
  [100, '#222222'],
  [50, '#1d4ed8'],
  [25, '#15803d'],
  [10, '#c62828'],
  [5, '#ececec'],
  [1, '#f5c518'],
];

export function chipBreakdown(amount, maxPerStack = 14) {
  let left = Math.max(0, Math.floor(amount));
  const out = [];
  for (const [v, color] of DENOMS) {
    const n = Math.floor(left / v);
    if (n > 0) {
      out.push({ value: v, color, count: Math.min(n, maxPerStack) });
      left -= n * v;
    }
  }
  return out;
}

const R = 0.2;
const T = 0.062;

function Chip({ color, y }) {
  return (
    <group position-y={y}>
      <mesh castShadow receiveShadow>
        <cylinderGeometry args={[R, R, T, 28]} />
        <meshStandardMaterial color={color} roughness={0.45} metalness={0.1} />
      </mesh>
      {/* แถบขาวรอบขอบชิป */}
      <mesh>
        <cylinderGeometry args={[R + 0.004, R + 0.004, T * 0.38, 28]} />
        <meshStandardMaterial color="#f4f1e6" roughness={0.5} />
      </mesh>
      {/* วงกลมตกแต่งด้านบน */}
      <mesh position-y={T / 2 + 0.0008} rotation-x={-Math.PI / 2}>
        <ringGeometry args={[R * 0.52, R * 0.66, 28]} />
        <meshStandardMaterial color="#f4f1e6" roughness={0.5} />
      </mesh>
    </group>
  );
}

/** กองชิปตามจำนวนเงิน: แต่ละมูลค่าเป็นหนึ่งกอง จัดเรียงเป็นกลุ่ม */
export default function ChipStacks({ amount, position = [0, 0, 0], scale = 1 }) {
  const stacks = useMemo(() => chipBreakdown(amount), [amount]);
  if (!amount) return null;
  const cols = Math.min(4, Math.max(1, Math.ceil(Math.sqrt(stacks.length * 1.4))));
  return (
    <group position={position} scale={scale}>
      {stacks.map((s, i) => {
        const col = i % cols;
        const row = Math.floor(i / cols);
        const x = (col - (Math.min(cols, stacks.length) - 1) / 2) * 0.46 + (row % 2) * 0.12;
        const z = row * 0.42 - (Math.ceil(stacks.length / cols) - 1) * 0.21;
        return (
          <group key={s.value} position={[x, 0, z]}>
            {Array.from({ length: s.count }).map((_, k) => (
              <Chip key={k} color={s.color} y={T / 2 + k * T} />
            ))}
          </group>
        );
      })}
    </group>
  );
}

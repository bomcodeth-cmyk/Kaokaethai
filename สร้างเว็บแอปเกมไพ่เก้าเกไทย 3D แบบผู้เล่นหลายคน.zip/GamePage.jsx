import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Coins, Copy, Eye, EyeOff, Hand, Minus, Play, Plus, Swords, Trophy, Volume2, VolumeX, X, Users, Timer } from 'lucide-react';
import Table3D, { useCountdown } from '../game/Table3D.jsx';
import { isMuted, play, setMuted } from '../lib/sound.js';

const fmt = (n) => Number(n).toLocaleString('th-TH');

const PHASE_LABEL = {
  waiting: 'รอเริ่มเกม',
  dealing: 'สับและแจกไพ่',
  bet1: 'รอบเดิมพันที่ 1',
  draw: 'แจกไพ่ใบที่ 3',
  bet2: 'รอบเดิมพันที่ 2',
  showdown: 'เปิดไพ่',
  result: 'สรุปผลตา',
  over: 'จบเกม',
};

export default function GamePage({ room, user, credits, emit, notify, connected }) {
  const me = room.players.find((p) => p.userId === user.id);
  const [peeked, setPeeked] = useState(() => new Set());
  const [muted, setM] = useState(isMuted());
  const [busy, setBusy] = useState(false);
  const [raiseK, setRaiseK] = useState(1);
  const isOwner = room.ownerId === user.id;
  const ante = room.settings.ante;
  const canAct = room.you.canAct;
  const left = useCountdown(room);

  // ตาใหม่ -> ซ่อนไพ่อีกครั้ง
  useEffect(() => setPeeked(new Set()), [room.handNo]);
  useEffect(() => setRaiseK((k) => Math.min(Math.max(1, k), Math.max(1, room.you.maxRaiseK))), [room.you.maxRaiseK, room.turnUid]);

  // เสียงเตือนเมื่อถึงตาเรา + เสียงติ๊กนับถอยหลัง 5 วินาทีสุดท้าย
  useEffect(() => {
    if (canAct) play('turn');
  }, [canAct, room.turnUid, room.phase]);
  const secLeft = left === null ? null : Math.ceil(left);
  useEffect(() => {
    if (secLeft !== null && secLeft > 0 && secLeft <= 5 && canAct) play('tick');
  }, [secLeft, canAct]);

  const act = useCallback(
    async (payload) => {
      if (busy) return;
      setBusy(true);
      const r = await emit('game:action', payload);
      setBusy(false);
      if (!r.ok) notify(r.error || 'ทำรายการไม่สำเร็จ', 'error');
    },
    [busy, emit, notify],
  );

  // คีย์ลัด: F หมอบ, C สู้, R เก
  useEffect(() => {
    const h = (e) => {
      if (!canAct || e.target.tagName === 'INPUT') return;
      const k = e.key.toLowerCase();
      if (k === 'f') act({ type: 'fold' });
      if (k === 'c') act({ type: 'call' });
      if (k === 'r' && room.you.maxRaiseK > 0) act({ type: 'raise', k: raiseK });
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [canAct, act, raiseK, room.you.maxRaiseK]);

  const myCardCount = me?.cardCount ?? 0;
  const togglePeek = (i) =>
    setPeeked((s) => {
      const n = new Set(s);
      n.has(i) ? n.delete(i) : n.add(i);
      play('click');
      return n;
    });
  const peekAll = () =>
    setPeeked((s) => (s.size >= myCardCount ? new Set() : new Set(Array.from({ length: myCardCount }, (_, i) => i))));

  const leave = async () => {
    const live = me?.inHand && !me.folded && !['result', 'over', 'waiting'].includes(room.phase);
    if (live && !window.confirm('ออกกลางตาจะถือว่าหมอบ และเงินที่ลงไปแล้วจะอยู่ในหม้อ ต้องการออกหรือไม่?')) return;
    const r = await emit('room:leave');
    if (!r.ok) notify(r.error || 'ออกจากโต๊ะไม่สำเร็จ', 'error');
  };

  const start = async () => {
    const r = await emit('room:start');
    if (!r.ok) notify(r.error || 'เริ่มเกมไม่สำเร็จ', 'error');
  };

  const turnPlayer = room.players.find((p) => p.userId === room.turnUid);
  const playing = room.status === 'playing';
  const showLabel = me?.inHand && !me.folded && room.you.myLabel && (peeked.size > 0 || room.phase === 'result');
  const newBet = room.currentBet + raiseK * ante;

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#050f0a]">
      <div className="absolute inset-0">
        <Table3D room={room} myUid={user.id} peeked={peeked} onPeek={togglePeek} />
      </div>

      {/* แถบบน */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex flex-wrap items-start justify-between gap-2 p-3">
        <div className="pointer-events-auto flex flex-wrap items-center gap-2">
          <button className="btn btn-ghost !py-1.5" onClick={leave}>
            <ArrowLeft size={16} /> ออกจากโต๊ะ
          </button>
          <button
            className="btn btn-ghost !py-1.5 font-mono tracking-widest"
            title="คัดลอกรหัสห้อง"
            onClick={() => {
              navigator.clipboard?.writeText(room.code);
              notify(`คัดลอกรหัสห้อง ${room.code} แล้ว`);
            }}
          >
            {room.code} <Copy size={14} />
          </button>
          <div className="hidden items-center gap-3 rounded-xl border border-white/15 bg-black/50 px-3 py-1.5 text-xs text-white/80 sm:flex">
            <span className="flex items-center gap-1">
              <Coins size={13} className="text-gold" /> ต๋ง {fmt(ante)}
            </span>
            <span className="flex items-center gap-1">
              <Users size={13} /> {room.players.filter((p) => !p.left).length}/{room.settings.maxPlayers}
            </span>
            <span className="flex items-center gap-1">
              <Timer size={13} /> {room.settings.turnTime} วิ
            </span>
          </div>
        </div>

        <div className="pointer-events-none order-last w-full text-center sm:order-none sm:w-auto">
          <div className="inline-block rounded-2xl border border-gold/40 bg-black/65 px-4 py-1.5 backdrop-blur">
            <div className="text-xs font-bold tracking-wide text-gold-light">
              {playing ? `ตาที่ ${room.handNo}${room.settings.rounds ? ` / ${room.settings.rounds}` : ''} · ` : ''}
              {PHASE_LABEL[room.phase] || ''}
            </div>
            {room.message && <div className="max-w-[80vw] truncate text-sm text-white/90" data-testid="message">{room.message}</div>}
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <div className="flex items-center gap-2 rounded-xl border border-gold/40 bg-black/60 px-3 py-1.5 font-bold text-gold-light" data-testid="credits">
            <Coins size={16} /> {fmt(credits)}
          </div>
          <button
            className="btn btn-ghost !px-3 !py-1.5"
            onClick={() => {
              setMuted(!muted);
              setM(!muted);
            }}
            title="เสียง"
          >
            {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
          {!connected && <span className="rounded-lg bg-red-700 px-2 py-1 text-xs font-bold">กำลังเชื่อมต่อใหม่…</span>}
        </div>
      </div>

      {/* ปุ่มดูไพ่ + ป้ายแต้มของเรา */}
      {me?.inHand && myCardCount > 0 && (
        <div className="absolute bottom-[132px] left-3 z-30 flex flex-col items-start gap-2 sm:bottom-[120px]">
          {showLabel && (
            <div className="pop rounded-xl border border-gold bg-black/75 px-3 py-1.5 text-sm font-extrabold text-gold-light" data-testid="my-label">
              ไพ่ของคุณ: {room.you.myLabel}
            </div>
          )}
          <button className="btn btn-ghost !py-1.5 text-sm" onClick={peekAll}>
            {peeked.size >= myCardCount ? <EyeOff size={16} /> : <Eye size={16} />} {peeked.size >= myCardCount ? 'ซ่อนไพ่' : 'แง้มไพ่'}
          </button>
          <span className="hidden text-[11px] text-white/50 sm:block">คลิกที่ไพ่บนโต๊ะเพื่อแง้มทีละใบ</span>
        </div>
      )}

      {/* แถบการกระทำ */}
      <div className="absolute inset-x-0 bottom-0 z-30 flex justify-center p-3 pb-4">
        {room.status === 'waiting' && (
          <div className="panel pop w-full max-w-lg bg-black/70 p-4 text-center">
            <div className="mb-1 text-lg font-extrabold text-gold-light">รอผู้เล่น ({room.players.length}/{room.settings.maxPlayers})</div>
            <p className="mb-3 text-sm text-white/70">
              ชวนเพื่อนเข้าด้วยรหัสห้อง <b className="font-mono text-xl tracking-widest text-gold-light">{room.code}</b> · ต้องมีอย่างน้อย 2 คน
            </p>
            {isOwner ? (
              <button className="btn btn-gold px-8 text-lg" disabled={room.players.length < 2} onClick={start}>
                <Play size={18} /> เริ่มเกม
              </button>
            ) : (
              <div className="text-white/60">รอเจ้าของโต๊ะกดเริ่มเกม…</div>
            )}
          </div>
        )}

        {playing && canAct && (
          <div className="panel pop flex w-full max-w-3xl flex-wrap items-center justify-center gap-3 bg-black/75 p-3" data-testid="action-bar">
            <div className="mr-1 text-center text-xs text-white/70">
              <div className="font-bold text-gold-light">ตาของคุณ</div>
              <div className="font-mono text-lg font-black">{secLeft}s</div>
            </div>
            <button className="btn btn-red" disabled={busy} onClick={() => act({ type: 'fold' })} data-testid="btn-fold">
              <X size={18} /> หมอบ <kbd className="hidden rounded bg-black/30 px-1 text-[10px] sm:inline">F</kbd>
            </button>
            <button className="btn btn-green" disabled={busy} onClick={() => act({ type: 'call' })} data-testid="btn-call">
              <Hand size={18} /> {room.you.toCall > 0 ? `สู้ ${fmt(room.you.toCall)}` : 'ผ่าน (สู้ 0)'} <kbd className="hidden rounded bg-black/30 px-1 text-[10px] sm:inline">C</kbd>
            </button>
            <div className="flex items-center gap-1 rounded-xl border border-gold/40 bg-gold/10 p-1">
              <button className="btn btn-ghost !p-2" disabled={raiseK <= 1} onClick={() => setRaiseK((k) => Math.max(1, k - 1))} aria-label="ลด">
                <Minus size={16} />
              </button>
              <div className="min-w-[86px] text-center leading-tight">
                <div className="text-sm font-extrabold text-gold-light">เก +{fmt(raiseK * ante)}</div>
                <div className="text-[10px] text-white/60">เป็น {fmt(newBet)}</div>
              </div>
              <button
                className="btn btn-ghost !p-2"
                disabled={raiseK >= room.you.maxRaiseK}
                onClick={() => setRaiseK((k) => Math.min(room.you.maxRaiseK, k + 1))}
                aria-label="เพิ่ม"
              >
                <Plus size={16} />
              </button>
              <button className="btn btn-gold" disabled={busy || room.you.maxRaiseK < 1} onClick={() => act({ type: 'raise', k: raiseK })} data-testid="btn-raise">
                <Swords size={18} /> เก <kbd className="hidden rounded bg-black/30 px-1 text-[10px] sm:inline">R</kbd>
              </button>
            </div>
          </div>
        )}

        {playing && !canAct && ['bet1', 'bet2'].includes(room.phase) && (
          <div className="panel bg-black/70 px-5 py-3 text-center text-sm text-white/80">
            {me?.folded ? 'คุณหมอบแล้ว — ' : ''}รอ <b className="text-gold-light">{turnPlayer?.name ?? '…'}</b> ตัดสินใจ
            {room.you.userId && me?.inHand && !me.folded && room.currentBet > 0 ? ` · เดิมพันรอบนี้ ${fmt(room.currentBet)}` : ''}
          </div>
        )}
        {playing && me && !me.inHand && room.phase !== 'result' && (
          <div className="panel bg-black/70 px-5 py-3 text-center text-sm text-amber-200">
            {credits < ante ? `เครดิตไม่พอจ่ายค่าต๋ง (${ante}) — ติดต่อแอดมินเพื่อเติมเครดิต` : 'คุณจะได้เล่นในตาถัดไป'}
          </div>
        )}
      </div>

      {/* แบนเนอร์ผู้ชนะ */}
      {room.phase === 'result' && room.result && (
        <div className="pointer-events-none absolute inset-x-0 top-[22%] z-20 flex justify-center">
          <div className="pop rounded-3xl border-2 border-gold bg-black/75 px-8 py-4 text-center shadow-[0_0_60px_rgba(212,175,55,.45)]" data-testid="winner-banner">
            <div className="flex items-center justify-center gap-2 text-sm font-bold tracking-widest text-gold-light">
              <Trophy size={16} /> ผู้ชนะ
            </div>
            <div className="text-3xl font-black text-white">{room.result.winnerUid === user.id ? 'คุณชนะ!' : room.result.winnerName}</div>
            <div className="text-xl font-extrabold text-gold-light">+{fmt(room.result.pot)}</div>
            <div className="text-xs text-white/60">
              {room.result.byFold
                ? 'ผู้เล่นที่เหลือหมอบหมด — ได้หม้อทันทีโดยไม่ต้องเปิดไพ่'
                : room.players.find((p) => p.userId === room.result.winnerUid)?.handLabel}
            </div>
          </div>
        </div>
      )}

      {/* จบเกม */}
      {room.status === 'finished' && room.finishInfo && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="panel pop w-full max-w-md bg-[#0a2417] p-6">
            <h2 className="mb-1 text-center text-2xl font-black text-gold-light">จบเกม</h2>
            <p className="mb-4 text-center text-sm text-white/60">
              เล่นไป {room.finishInfo.hands} ตา · {room.finishInfo.reason}
            </p>
            <div className="mb-4 space-y-2">
              {[...room.finishInfo.net]
                .sort((a, b) => b.net - a.net)
                .map((r, i) => (
                  <div key={r.userId} className="flex items-center justify-between rounded-xl bg-black/30 px-3 py-2">
                    <span className="font-bold">
                      {i === 0 && r.net > 0 ? '🏆 ' : ''}
                      {r.name}
                      {r.userId === user.id ? ' (คุณ)' : ''}
                    </span>
                    <span className={`font-extrabold ${r.net >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>
                      {r.net >= 0 ? '+' : ''}
                      {fmt(r.net)}
                    </span>
                  </div>
                ))}
            </div>
            <div className="flex gap-2">
              {isOwner && (
                <button className="btn btn-gold flex-1" onClick={start}>
                  <Play size={16} /> เล่นอีกครั้ง
                </button>
              )}
              <button className="btn btn-ghost flex-1" onClick={leave}>
                กลับล็อบบี้
              </button>
            </div>
            {!isOwner && <p className="mt-2 text-center text-xs text-white/50">รอเจ้าของโต๊ะเริ่มเกมใหม่ หรือกลับล็อบบี้</p>}
          </div>
        </div>
      )}
    </div>
  );
}

"""E2E: แผงแอดมิน (ตรวจรหัส, ค้นหา, ปรับเครดิตแล้วสะท้อนบนหน้าจอผู้เล่นออนไลน์) + มุมมองมือถือ"""
import asyncio, os
from playwright.async_api import async_playwright

BASE = 'http://localhost:3001'
OUT = '/home/ubuntu/shots'

async def main():
    os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        # ผู้เล่นออนไลน์บนมือถือ
        mctx = await b.new_context(viewport={'width': 390, 'height': 780}, device_scale_factor=2, is_mobile=True, has_touch=True, locale='th-TH')
        m = await mctx.new_page()
        m.on('pageerror', lambda e: print('PAGEERROR mobile:', e))
        await m.goto(BASE)
        await m.wait_for_selector('input[autocomplete="username"]')
        await m.click('text=สมัครสมาชิก >> nth=0')
        await m.fill('input[autocomplete="username"]', 'mobileuser')
        await m.fill('input[autocomplete="new-password"]', 'secret123')
        await m.click('button:has-text("สมัครและรับเครดิตเริ่มต้น")')
        await m.wait_for_selector('[data-testid=credits]')
        print('mobile credits before:', (await m.inner_text('[data-testid=credits]')).strip())
        await m.screenshot(path=f'{OUT}/10_mobile_lobby.png')

        # แอดมิน
        actx = await b.new_context(viewport={'width': 1360, 'height': 800}, locale='th-TH')
        a = await actx.new_page()
        a.on('pageerror', lambda e: print('PAGEERROR admin:', e))
        await a.goto(BASE + '/admin')
        await a.wait_for_selector('[data-testid=admin-code]')
        await a.fill('[data-testid=admin-code]', 'wrongcode')
        await a.click('button:has-text("เข้าสู่แผงแอดมิน")')
        await a.wait_for_selector('text=รหัสเข้าถึงไม่ถูกต้อง')
        print('wrong code rejected: ok')
        await a.screenshot(path=f'{OUT}/11_admin_gate.png')
        await a.fill('[data-testid=admin-code]', 'bigboss2026')
        await a.click('button:has-text("เข้าสู่แผงแอดมิน")')
        await a.wait_for_selector('[data-testid=admin-row]')
        await a.fill('[data-testid=admin-search]', 'mobile')
        await a.wait_for_timeout(900)
        rows = await a.locator('[data-testid=admin-row]').count()
        print('search rows:', rows)
        row = a.locator('[data-testid=admin-row]').first
        await row.locator('[data-testid=admin-amount]').fill('5000')
        await row.locator('[data-testid=admin-set]').click()
        await a.wait_for_timeout(800)
        await row.locator('[data-testid=admin-amount]').fill('250')
        await row.locator('[data-testid=admin-add]').click()
        await a.wait_for_timeout(1000)
        print('admin row credits:', (await row.locator('[data-testid=admin-credits]').inner_text()).strip())
        print('mobile credits after (live push):', (await m.inner_text('[data-testid=credits]')).strip())
        await a.fill('[data-testid=admin-search]', '')
        await a.wait_for_timeout(900)
        await a.screenshot(path=f'{OUT}/12_admin.png')
        # ไม่มีโทเคน -> ข้ามหน้า gate ด้วยการเรียก API ตรง ๆ ต้องไม่ได้
        r = await a.request.get(BASE + '/api/admin/users')
        print('admin api without token ->', r.status)
        await b.close()

asyncio.run(main())

import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { backTexture, frontTexture, CARD_H, CARD_W } from './cardTextures.js';

const damp = THREE.MathUtils.damp;
const HALF_H = CARD_H / 2;
const PEEK_PHI = 1.05;

/** แปลงโหมดการวางไพ่ เป็นมุมพลิก + การชดเชยตำแหน่ง (ให้ขอบล่างของไพ่ที่แง้มติดโต๊ะ) */
function pose(mode) {
  if (mode === 'up') return { phi: 0, iy: 0.012, iz: 0 };
  if (mode === 'peek') return { phi: PEEK_PHI, iy: HALF_H * Math.sin(PEEK_PHI) + 0.02, iz: HALF_H * (1 - Math.cos(PEEK_PHI)) };
  return { phi: Math.PI, iy: 0.012, iz: 0 };
}

/**
 * ไพ่ 1 ใบ: บินจาก startPos (กองกลาง) ไปยัง target พร้อมพลิกหงาย/คว่ำ/แง้ม
 * card = null หมายถึงไม่รู้หน้าไพ่ (ของคนอื่น) -> แสดงเฉพาะหลังไพ่เสมอ
 */
export default function Card3D({ card, target, startPos, delay = 0, dim = false, onClick, interactive = false }) {
  const outer = useRef();
  const inner = useRef();
  const cur = useRef(null);
  const born = useRef(performance.now());

  const front = useMemo(() => (card ? frontTexture(card.r, card.s) : backTexture()), [card?.r, card?.s]);
  const back = useMemo(() => backTexture(), []);

  if (!cur.current) {
    const p = pose('down');
    cur.current = { x: startPos[0], y: startPos[1] + 0.2, z: startPos[2], yaw: target.yaw, phi: p.phi, iy: p.iy, iz: p.iz };
  }

  useFrame((_, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05);
    const c = cur.current;
    const g = outer.current;
    const ig = inner.current;
    if (!g || !ig) return;
    if ((performance.now() - born.current) / 1000 < delay) {
      g.visible = false;
      return;
    }
    g.visible = true;
    const p = pose(target.mode);
    const k = 7;
    const dx = target.x - c.x;
    const dz = target.z - c.z;
    const dist = Math.hypot(dx, dz);
    c.x = damp(c.x, target.x, k, dt);
    c.z = damp(c.z, target.z, k, dt);
    c.yaw = damp(c.yaw, target.yaw, k, dt);
    c.phi = damp(c.phi, p.phi, 8, dt);
    c.iy = damp(c.iy, p.iy, 8, dt);
    c.iz = damp(c.iz, p.iz, 8, dt);
    const flipBump = 0.4 * Math.min(1, Math.abs(c.phi - p.phi));
    const arc = Math.min(dist, 4) * 0.16;
    c.y = damp(c.y, target.y, k, dt);
    g.position.set(c.x, c.y + arc + flipBump, c.z);
    g.rotation.set(0, c.yaw, 0);
    ig.rotation.set(c.phi, 0, 0);
    ig.position.set(0, c.iy, c.iz);
  });

  const tint = dim ? '#7d7d7d' : '#ffffff';
  return (
    <group
      ref={outer}
      visible={false}
      onClick={
        interactive
          ? (e) => {
              e.stopPropagation();
              onClick?.();
            }
          : undefined
      }
      onPointerOver={interactive ? () => (document.body.style.cursor = 'pointer') : undefined}
      onPointerOut={interactive ? () => (document.body.style.cursor = '') : undefined}
    >
      <group ref={inner}>
        {/* หน้าไพ่ (หันขึ้นเมื่อ phi=0) */}
        <mesh rotation-x={-Math.PI / 2} position-y={0.007} castShadow>
          <planeGeometry args={[CARD_W, CARD_H]} />
          <meshStandardMaterial map={front} color={tint} transparent alphaTest={0.5} roughness={0.5} metalness={0} />
        </mesh>
        {/* หลังไพ่ */}
        <mesh rotation-x={Math.PI / 2} position-y={-0.007}>
          <planeGeometry args={[CARD_W, CARD_H]} />
          <meshStandardMaterial map={back} color={tint} transparent alphaTest={0.5} roughness={0.5} metalness={0} />
        </mesh>
        {/* ความหนาของไพ่ */}
        <mesh castShadow receiveShadow>
          <boxGeometry args={[CARD_W - 0.04, 0.012, CARD_H - 0.04]} />
          <meshStandardMaterial color="#e9e4d2" roughness={0.8} />
        </mesh>
      </group>
    </group>
  );
}

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { Lock, Search, Plus, Minus, Equal, Trash2, KeyRound, RefreshCw, Users, Wifi, LogOut, ShieldCheck } from 'lucide-react';
import { adminTokenStore, api } from '../lib/api.js';
import Modal from '../components/Modal.jsx';

const fmt = (n) => Number(n).toLocaleString('th-TH');

function Gate({ onOk }) {
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  return (
    <div className="bg-casino flex h-full items-center justify-center p-4">
      <form
        className="panel w-full max-w-sm space-y-4 p-6"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setErr('');
          try {
            // ตรวจรหัสที่เซิร์ฟเวอร์เท่านั้น — client ไม่ได้เก็บรหัสไว้
            const r = await api('/api/admin/login', { method: 'POST', body: { code } });
            adminTokenStore.set(r.token);
            onOk(r.token);
          } catch (e2) {
            setErr(e2.message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <div className="text-center">
          <Lock className="mx-auto mb-2 text-gold" size={32} />
          <h1 className="text-2xl font-extrabold text-gold-light">แผงแอดมิน</h1>
          <p className="text-sm text-white/60">กรอกรหัสเข้าถึงเพื่อดูข้อมูล</p>
        </div>
        <input className="input text-center" type="password" placeholder="รหัสเข้าถึง" value={code} onChange={(e) => setCode(e.target.value)} autoFocus data-testid="admin-code" />
        {err && <div className="rounded-lg bg-red-900/60 px-3 py-2 text-sm">{err}</div>}
        <button className="btn btn-gold w-full" disabled={busy || !code}>
          เข้าสู่แผงแอดมิน
        </button>
        <a className="block text-center text-xs text-white/40 hover:text-white/70" href="/">
          ← กลับหน้าเกม
        </a>
      </form>
    </div>
  );
}

export default function Admin() {
  const [token, setToken] = useState(adminTokenStore.get());
  if (!token) return <Gate onOk={setToken} />;
  return (
    <Panel
      token={token}
      onLogout={() => {
        adminTokenStore.clear();
        setToken(null);
      }}
    />
  );
}

function Panel({ token, onLogout }) {
  const [users, setUsers] = useState([]);
  const [meta, setMeta] = useState({ onlineCount: 0, rooms: 0 });
  const [q, setQ] = useState('');
  const [amounts, setAmounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);
  const [pwTarget, setPwTarget] = useState(null);
  const [delTarget, setDelTarget] = useState(null);
  const qRef = useRef(q);
  qRef.current = q;

  const flash = (text, kind = 'ok') => {
    setMsg({ text, kind });
    setTimeout(() => setMsg(null), 3000);
  };

  const load = useCallback(async () => {
    try {
      const r = await api(`/api/admin/users?q=${encodeURIComponent(qRef.current)}`, { token });
      setUsers(r.users);
      setMeta({ onlineCount: r.onlineCount, rooms: r.rooms });
    } catch (e) {
      if (e.status === 401) onLogout();
      else flash(e.message, 'err');
    } finally {
      setLoading(false);
    }
  }, [token, onLogout]);

  useEffect(() => {
    const t = setTimeout(load, 200);
    return () => clearTimeout(t);
  }, [q, load]);

  // อัปเดตสดผ่าน socket (ผู้เล่นออนไลน์/ออฟไลน์/เครดิตเปลี่ยน) + สำรองด้วย polling
  useEffect(() => {
    const s = io({ auth: { adminToken: token }, transports: ['websocket', 'polling'] });
    s.on('admin:changed', load);
    const iv = setInterval(load, 8000);
    return () => {
      s.disconnect();
      clearInterval(iv);
    };
  }, [token, load]);

  const adjust = async (u, mode) => {
    const amount = Math.floor(Number(amounts[u.id]));
    if (!Number.isFinite(amount) || amount < 0 || amounts[u.id] === undefined || amounts[u.id] === '') return flash('กรอกจำนวนเครดิตก่อน', 'err');
    try {
      const r = await api(`/api/admin/users/${u.id}/credits`, { method: 'POST', token, body: { mode, amount } });
      flash(`${u.username}: เครดิตเป็น ${fmt(r.credits)}`);
      load();
    } catch (e) {
      flash(e.message, 'err');
    }
  };

  const totals = useMemo(() => users.reduce((a, u) => a + u.credits, 0), [users]);

  return (
    <div className="bg-casino flex h-full flex-col">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-gold/25 bg-black/30 px-4 py-3">
        <h1 className="flex items-center gap-2 text-xl font-extrabold text-gold-light">
          <ShieldCheck size={22} /> แผงแอดมิน · เก้าเกไทย
        </h1>
        <div className="flex items-center gap-2 text-sm">
          <span className="flex items-center gap-1 rounded-lg bg-black/40 px-3 py-1.5">
            <Users size={14} /> ผู้เล่น <b>{users.length}</b>
          </span>
          <span className="flex items-center gap-1 rounded-lg bg-black/40 px-3 py-1.5 text-emerald-300">
            <Wifi size={14} /> ออนไลน์ <b>{meta.onlineCount}</b>
          </span>
          <span className="rounded-lg bg-black/40 px-3 py-1.5">โต๊ะ <b>{meta.rooms}</b></span>
          <button className="btn btn-ghost !py-1.5" onClick={load}>
            <RefreshCw size={14} />
          </button>
          <a className="btn btn-ghost !py-1.5" href="/">
            หน้าเกม
          </a>
          <button className="btn btn-ghost !py-1.5" onClick={onLogout}>
            <LogOut size={14} /> ออก
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-auto p-4 scroll-thin">
        <div className="mx-auto max-w-6xl">
          <div className="mb-3 flex items-center gap-3">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
              <input className="input !pl-9" placeholder="ค้นหาชื่อผู้เล่น…" value={q} onChange={(e) => setQ(e.target.value)} data-testid="admin-search" />
            </div>
            <div className="text-sm text-white/60">เครดิตรวม {fmt(totals)}</div>
          </div>

          <div className="panel overflow-x-auto">
            <table className="w-full min-w-[860px] text-sm">
              <thead className="text-left text-white/60">
                <tr className="border-b border-white/10">
                  <th className="p-3">ผู้เล่น</th>
                  <th className="p-3">สถานะ</th>
                  <th className="p-3 text-right">เครดิต</th>
                  <th className="p-3 text-center">ชนะ / แพ้</th>
                  <th className="p-3">จัดการเครดิต</th>
                  <th className="p-3 text-right">บัญชี</th>
                </tr>
              </thead>
              <tbody>
                {loading && (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-white/50">
                      กำลังโหลด…
                    </td>
                  </tr>
                )}
                {!loading && users.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-white/50">
                      ไม่พบผู้เล่น
                    </td>
                  </tr>
                )}
                {users.map((u) => (
                  <tr key={u.id} className="border-b border-white/5 hover:bg-white/5" data-testid="admin-row">
                    <td className="p-3">
                      <div className="font-bold">{u.username}</div>
                      <div className="text-[11px] text-white/40">#{u.id} · สมัคร {new Date(u.createdAt).toLocaleDateString('th-TH')}</div>
                    </td>
                    <td className="p-3">
                      {u.online ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/20 px-2 py-0.5 text-xs font-bold text-emerald-300">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> ออนไลน์{u.room ? ` · โต๊ะ ${u.room}` : ''}
                        </span>
                      ) : (
                        <span className="rounded-full bg-white/10 px-2 py-0.5 text-xs text-white/50">ออฟไลน์</span>
                      )}
                    </td>
                    <td className="p-3 text-right font-extrabold text-gold-light" data-testid="admin-credits">{fmt(u.credits)}</td>
                    <td className="p-3 text-center">
                      <span className="text-emerald-300">{u.wins}</span> / <span className="text-red-300">{u.losses}</span>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-1">
                        <input
                          className="input !w-24 !py-1.5"
                          type="number"
                          min={0}
                          placeholder="จำนวน"
                          value={amounts[u.id] ?? ''}
                          onChange={(e) => setAmounts((a) => ({ ...a, [u.id]: e.target.value }))}
                          data-testid="admin-amount"
                        />
                        <button className="btn btn-green !p-2" title="+ เครดิต" onClick={() => adjust(u, 'add')} data-testid="admin-add">
                          <Plus size={14} />
                        </button>
                        <button className="btn btn-red !p-2" title="- เครดิต" onClick={() => adjust(u, 'sub')} data-testid="admin-sub">
                          <Minus size={14} />
                        </button>
                        <button className="btn btn-gold !p-2" title="ตั้งเครดิตเป็น" onClick={() => adjust(u, 'set')} data-testid="admin-set">
                          <Equal size={14} />
                        </button>
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex justify-end gap-1">
                        <button className="btn btn-ghost !px-2 !py-1.5 text-xs" onClick={() => setPwTarget(u)}>
                          <KeyRound size={13} /> รีเซ็ตรหัสผ่าน
                        </button>
                        <button className="btn btn-ghost !px-2 !py-1.5 text-xs text-red-300" onClick={() => setDelTarget(u)}>
                          <Trash2 size={13} /> ลบ
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {msg && (
        <div className={`pop fixed bottom-4 left-1/2 z-[100] -translate-x-1/2 rounded-xl px-5 py-3 text-sm font-bold shadow-2xl ${msg.kind === 'err' ? 'bg-red-700' : 'bg-gold text-black'}`}>
          {msg.text}
        </div>
      )}

      {pwTarget && (
        <PasswordModal
          user={pwTarget}
          onClose={() => setPwTarget(null)}
          onSubmit={async (password) => {
            try {
              await api(`/api/admin/users/${pwTarget.id}/password`, { method: 'POST', token, body: { password } });
              flash(`รีเซ็ตรหัสผ่านของ ${pwTarget.username} แล้ว`);
              setPwTarget(null);
            } catch (e) {
              flash(e.message, 'err');
            }
          }}
        />
      )}
      {delTarget && (
        <Modal title="ลบผู้เล่น" onClose={() => setDelTarget(null)}>
          <p className="mb-4 text-white/80">
            ต้องการลบบัญชี <b className="text-gold-light">{delTarget.username}</b> อย่างถาวรหรือไม่? เครดิตและประวัติทั้งหมดจะหายไป
          </p>
          <div className="flex gap-2">
            <button
              className="btn btn-red flex-1"
              data-testid="confirm-delete"
              onClick={async () => {
                try {
                  await api(`/api/admin/users/${delTarget.id}`, { method: 'DELETE', token });
                  flash(`ลบ ${delTarget.username} แล้ว`);
                  setDelTarget(null);
                  load();
                } catch (e) {
                  flash(e.message, 'err');
                }
              }}
            >
              ลบถาวร
            </button>
            <button className="btn btn-ghost flex-1" onClick={() => setDelTarget(null)}>
              ยกเลิก
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function PasswordModal({ user, onClose, onSubmit }) {
  const [pw, setPw] = useState('');
  return (
    <Modal title={`รีเซ็ตรหัสผ่าน: ${user.username}`} onClose={onClose}>
      <form
        className="space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          onSubmit(pw);
        }}
      >
        <input className="input" type="text" placeholder="รหัสผ่านใหม่ (อย่างน้อย 6 ตัวอักษร)" value={pw} onChange={(e) => setPw(e.target.value)} autoFocus />
        <p className="text-xs text-white/50">ผู้เล่นที่ล็อกอินอยู่จะถูกออกจากระบบและต้องใช้รหัสผ่านใหม่</p>
        <button className="btn btn-gold w-full" disabled={pw.length < 6}>
          ยืนยันรีเซ็ต
        </button>
      </form>
    </Modal>
  );
}

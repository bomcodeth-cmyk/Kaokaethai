// เอนจินของโต๊ะ: แจกไพ่ รอบเดิมพัน จับเวลา ตัดสิน โอนเครดิต — ทั้งหมดอยู่ฝั่งเซิร์ฟเวอร์
// ทุกการเปลี่ยนแปลงสถานะวิ่งผ่านคิว (run) ทีละงาน จึงไม่มี race condition จากการกดซ้ำ/พร้อมกัน
import { config } from './config.js';
import { prisma } from './db.js';
import { makeDeck, shuffle, evaluate, compareHands } from './cards.js';
import { hub, emitToUser } from './state.js';
import { debitToEscrow, settleHand } from './wallet.js';

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export function newCode() {
  for (;;) {
    let c = '';
    for (let i = 0; i < 4; i++) c += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
    if (!hub.rooms.has(c)) return c;
  }
}

const fail = (error) => ({ ok: false, error });

export class Room {
  constructor({ code, owner, settings }) {
    this.code = code;
    this.ownerId = owner.id;
    this.settings = settings; // { rounds, maxPlayers, turnTime, ante }
    this.players = []; // { userId, name, seat, credits, online, left, offlineTimer }
    this.status = 'waiting'; // waiting | playing | finished
    this.handNo = 0;
    this.hand = null;
    this.sessionNet = {};
    this.lastFirstSeat = -1;
    this.message = '';
    this.finishInfo = null;
    this.q = Promise.resolve();
    this.stepTimer = null;
    this.stepId = 0;
    this.turnTimer = null;
    this.turnToken = 0;
    this.destroyed = false;
  }

  /** ต่อคิวงานที่แก้สถานะของโต๊ะ (ทำทีละงานตามลำดับ) */
  run(fn) {
    const p = this.q.then(fn);
    this.q = p.catch((e) => console.error(`[room ${this.code}]`, e));
    return p;
  }

  // ---------- ตัวช่วย ----------
  player(uid) {
    return this.players.find((p) => p.userId === uid);
  }
  get ante() {
    return this.settings.ante;
  }
  activeUids() {
    return this.hand ? this.hand.order.filter((u) => !this.hand.folded.has(u)) : [];
  }
  emitFx(name) {
    hub.io?.to(`room:${this.code}`).emit('room:fx', { name });
  }

  async refreshCredits() {
    if (!this.players.length) return;
    const users = await prisma.user.findMany({
      where: { id: { in: this.players.map((p) => p.userId) } },
      select: { id: true, credits: true },
    });
    for (const u of users) {
      const p = this.player(u.id);
      if (p) p.credits = u.credits;
    }
  }

  /** เรียกเมื่อเครดิตเปลี่ยนจากภายนอก (เช่นแอดมิน) */
  async syncCredits() {
    if (this.destroyed) return;
    await this.refreshCredits();
    this.broadcast();
  }

  async pushMe(uid) {
    const p = this.player(uid);
    if (p) emitToUser(uid, 'me:credits', { credits: p.credits });
  }

  // ---------- เข้า/ออกโต๊ะ ----------
  async join(user) {
    return this.run(async () => {
      if (this.destroyed) return fail('โต๊ะนี้ถูกปิดแล้ว');
      const existing = this.player(user.id);
      if (existing && !existing.left) {
        existing.online = true;
        clearTimeout(existing.offlineTimer);
        hub.userRoom.set(user.id, this.code);
        this.broadcast();
        return { ok: true };
      }
      if (existing && existing.left) return fail('คุณเพิ่งออกจากโต๊ะนี้ รอจบตาปัจจุบันก่อน');
      if (this.players.length >= this.settings.maxPlayers) return fail('โต๊ะเต็มแล้ว');
      const need = this.ante * config.joinMultiplier;
      if (user.credits < need) return fail(`ต้องมีเครดิตอย่างน้อย ${need} เพื่อเข้าโต๊ะนี้ (ค่าต๋ง ${this.ante} x ${config.joinMultiplier})`);
      const used = new Set(this.players.map((p) => p.seat));
      let seat = 0;
      while (used.has(seat)) seat++;
      this.players.push({ userId: user.id, name: user.username, seat, credits: user.credits, online: true, left: false, offlineTimer: null });
      this.sessionNet[user.id] ??= 0;
      hub.userRoom.set(user.id, this.code);
      this.message = `${user.username} เข้าร่วมโต๊ะ`;
      this.emitFx('join');
      this.broadcast();
      return { ok: true };
    });
  }

  /** ออกจากโต๊ะ: ถ้าอยู่ในตาที่กำลังเล่นจะถือว่าหมอบ (เงินที่ลงไปแล้วอยู่ในหม้อ) */
  async leave(uid) {
    return this.run(async () => {
      const p = this.player(uid);
      if (!p || this.destroyed) return { ok: true };
      clearTimeout(p.offlineTimer);
      hub.userRoom.delete(uid);
      const h = this.hand;
      const inLiveHand = h && h.live && h.order.includes(uid);
      if (inLiveHand) {
        p.left = true; // เก็บที่นั่งไว้จนจบตา เพื่อให้เห็นว่าหมอบ
        p.online = false;
        if (!h.folded.has(uid)) {
          h.folded.add(uid);
          h.lastAction[uid] = 'ออกจากโต๊ะ';
          this.message = `${p.name} ออกจากโต๊ะ`;
          if (h.turnUid === uid && ['bet1', 'bet2'].includes(h.phase)) {
            await this.afterAction(null);
          } else if (this.activeUids().length <= 1) {
            if (h.phase === 'dealing') h.foldWin = true; // รอจบจังหวะแจกไพ่
            else await this.finishByFold();
          }
        }
      } else {
        this.players = this.players.filter((x) => x.userId !== uid);
        this.message = `${p.name} ออกจากโต๊ะ`;
      }
      this.afterRosterChange();
      this.broadcast();
      return { ok: true };
    });
  }

  afterRosterChange() {
    const present = this.players.filter((p) => !p.left);
    if (!present.length) {
      this.destroy();
      return;
    }
    if (!present.some((p) => p.userId === this.ownerId)) {
      this.ownerId = present[0].userId;
      this.message = `${present[0].name} เป็นเจ้าของโต๊ะคนใหม่`;
    }
  }

  setOnline(uid, online) {
    const p = this.player(uid);
    if (!p || p.left) return;
    p.online = online;
    clearTimeout(p.offlineTimer);
    if (!online) p.offlineTimer = setTimeout(() => this.leave(uid), config.reconnectGraceMs);
    this.broadcast();
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    clearTimeout(this.stepTimer);
    clearTimeout(this.turnTimer);
    for (const p of this.players) {
      clearTimeout(p.offlineTimer);
      if (hub.userRoom.get(p.userId) === this.code) hub.userRoom.delete(p.userId);
    }
    hub.rooms.delete(this.code);
    broadcastLobby();
  }

  // ---------- เริ่มเกม ----------
  async start(uid) {
    return this.run(async () => {
      if (uid !== this.ownerId) return fail('เฉพาะเจ้าของโต๊ะเท่านั้นที่เริ่มเกมได้');
      if (this.status === 'playing') return fail('เกมกำลังดำเนินอยู่');
      await this.refreshCredits();
      const eligible = this.players.filter((p) => !p.left && p.credits >= this.ante);
      if (eligible.length < 2) return fail(`ต้องมีผู้เล่นที่มีเครดิตพอจ่ายค่าต๋ง (${this.ante}) อย่างน้อย 2 คน`);
      this.status = 'playing';
      this.handNo = 0;
      this.sessionNet = Object.fromEntries(this.players.map((p) => [p.userId, 0]));
      this.finishInfo = null;
      this.lastFirstSeat = -1;
      await this.beginHand();
      return { ok: true };
    });
  }

  async beginHand() {
    this.cleanupRoster();
    if (this.destroyed) return;
    await this.refreshCredits();
    const ante = this.ante;
    const candidates = this.players.filter((p) => !p.left && p.credits >= ante).sort((a, b) => a.seat - b.seat);
    if (candidates.length < 2) return this.endGame('ผู้เล่นที่มีเครดิตพอไม่ถึง 2 คน');

    // ลงต๋งอัตโนมัติ (หักเข้า escrow แบบ atomic)
    const paid = [];
    for (const p of candidates) if (await debitToEscrow(p.userId, ante)) paid.push(p);
    if (paid.length < 2) {
      for (const p of paid) {
        await prisma.user.updateMany({ where: { id: p.userId }, data: { credits: { increment: ante }, escrow: { decrement: ante } } });
      }
      await this.refreshCredits();
      return this.endGame('ผู้เล่นที่มีเครดิตพอไม่ถึง 2 คน');
    }
    const contrib = Object.fromEntries(paid.map((p) => [p.userId, ante]));

    // คนเริ่มก่อนหมุนเวียนตามที่นั่ง
    const seats = paid.map((p) => p.seat);
    const firstSeat = seats.find((s) => s > this.lastFirstSeat) ?? seats[0];
    this.lastFirstSeat = firstSeat;
    const at = paid.findIndex((p) => p.seat === firstSeat);
    const order = [...paid.slice(at), ...paid.slice(0, at)].map((p) => p.userId);

    const deck = shuffle(makeDeck());
    const cards = Object.fromEntries(order.map((u) => [u, []]));
    for (let i = 0; i < 2; i++) for (const u of order) cards[u].push(deck.pop());

    this.handNo += 1;
    this.hand = {
      live: true,
      phase: 'dealing',
      order,
      deck,
      cards,
      folded: new Set(),
      pot: ante * order.length,
      contrib,
      roundBet: {},
      currentBet: 0,
      acted: new Set(),
      turnUid: null,
      turnEndsAt: null,
      lastAction: {},
      result: null,
      foldWin: false,
    };
    this.message = `ตาที่ ${this.handNo}${this.settings.rounds ? `/${this.settings.rounds}` : ''} — ลงต๋งคนละ ${ante}`;
    await this.refreshCredits();
    for (const u of order) this.pushMe(u);
    this.emitFx('shuffle');
    this.broadcast();
    setTimeout(() => this.emitFx('deal'), 600);
    this.schedule(config.dealPauseMs, async () => {
      if (this.activeUids().length <= 1) return this.finishByFold();
      await this.startBetting(1);
    });
  }

  cleanupRoster() {
    this.players = this.players.filter((p) => !p.left);
    this.afterRosterChange();
  }

  /** ตั้งงานตามจังหวะ (หน่วงเวลา) — งานเก่าถูกยกเลิกอัตโนมัติเมื่อมีงานใหม่มาแทน */
  schedule(ms, fn) {
    clearTimeout(this.stepTimer);
    const id = ++this.stepId;
    this.stepTimer = setTimeout(() => {
      if (id !== this.stepId || this.destroyed) return;
      this.run(() => (id === this.stepId && !this.destroyed ? fn() : undefined));
    }, ms);
  }

  // ---------- รอบเดิมพัน ----------
  async startBetting(round) {
    const h = this.hand;
    h.phase = round === 1 ? 'bet1' : 'bet2';
    h.roundBet = Object.fromEntries(this.activeUids().map((u) => [u, 0]));
    h.currentBet = 0;
    h.acted = new Set();
    h.lastAction = {};
    this.message = round === 1 ? 'รอบเดิมพันที่ 1 — หมอบ / สู้ / เก' : 'รอบเดิมพันที่ 2 — หมอบ / สู้ / เก';
    this.setTurn(this.activeUids()[0]);
    this.broadcast();
  }

  setTurn(uid) {
    const h = this.hand;
    clearTimeout(this.turnTimer);
    h.turnUid = uid;
    h.turnEndsAt = Date.now() + this.settings.turnTime * 1000;
    const token = ++this.turnToken;
    const p = this.player(uid);
    // ผู้เล่นที่หลุดการเชื่อมต่อจะหมอบเร็วขึ้น
    const wait = p && !p.online ? 1500 : this.settings.turnTime * 1000;
    this.turnTimer = setTimeout(() => {
      this.run(async () => {
        if (token !== this.turnToken || !this.hand || this.hand.turnUid !== uid || this.destroyed) return;
        this.hand.folded.add(uid);
        this.hand.lastAction[uid] = 'หมดเวลา หมอบ';
        this.message = `${this.player(uid)?.name ?? ''} หมดเวลา — หมอบอัตโนมัติ`;
        this.emitFx('fold');
        await this.afterAction(null);
      });
    }, wait);
  }

  /** เพดานเดิมพันสูงสุดของรอบ: ทุกคนที่ยังอยู่ต้องจ่ายตามได้ (จึงไม่เกิดออลอิน/ไซด์พอต) */
  raiseCap() {
    const h = this.hand;
    let cap = Infinity;
    for (const u of this.activeUids()) {
      const p = this.player(u);
      cap = Math.min(cap, (p?.credits ?? 0) + (h.roundBet[u] || 0));
    }
    return cap;
  }

  maxRaiseK() {
    const h = this.hand;
    if (!h) return 0;
    const room = this.raiseCap() - h.currentBet;
    return Math.max(0, Math.min(config.maxRaiseK, Math.floor(room / this.ante)));
  }

  /** การกระทำของผู้เล่น — ตรวจที่เซิร์ฟเวอร์ทุกครั้งว่าเป็นตาของคนนั้นจริง */
  async action(uid, payload) {
    return this.run(async () => {
      const h = this.hand;
      if (this.destroyed || !h || !h.live || !['bet1', 'bet2'].includes(h.phase)) return fail('ตอนนี้ยังไม่ใช่รอบเดิมพัน');
      if (h.turnUid !== uid) return fail('ยังไม่ถึงตาของคุณ');
      if (h.folded.has(uid)) return fail('คุณหมอบไปแล้ว');
      const type = payload?.type;
      const name = this.player(uid)?.name ?? '';
      await this.refreshCredits();

      if (type === 'fold') {
        h.folded.add(uid);
        h.lastAction[uid] = 'หมอบ';
        this.message = `${name} หมอบ`;
        this.emitFx('fold');
      } else if (type === 'call') {
        const need = Math.max(0, h.currentBet - (h.roundBet[uid] || 0));
        if (need > 0 && !(await debitToEscrow(uid, need))) {
          h.folded.add(uid);
          h.lastAction[uid] = 'เครดิตไม่พอ หมอบ';
          this.message = `${name} เครดิตไม่พอ — หมอบ`;
        } else {
          h.roundBet[uid] = (h.roundBet[uid] || 0) + need;
          h.contrib[uid] += need;
          h.pot += need;
          h.acted.add(uid);
          h.lastAction[uid] = need > 0 ? `สู้ ${need}` : 'ผ่าน';
          this.message = `${name} ${need > 0 ? `สู้ ${need}` : 'ผ่าน'}`;
          this.emitFx(need > 0 ? 'chip' : 'check');
        }
      } else if (type === 'raise') {
        const k = Math.floor(Number(payload.k));
        if (!Number.isFinite(k) || k < 1 || k > config.maxRaiseK) return fail('จำนวนที่เกไม่ถูกต้อง');
        if (k > this.maxRaiseK()) return fail('เกได้ไม่เกินเครดิตของผู้เล่นที่เหลือ (ทุกคนต้องสู้ตามได้)');
        const newBet = h.currentBet + k * this.ante;
        const need = newBet - (h.roundBet[uid] || 0);
        if (!(await debitToEscrow(uid, need))) return fail('เครดิตไม่พอ');
        h.roundBet[uid] = newBet;
        h.contrib[uid] += need;
        h.pot += need;
        h.currentBet = newBet;
        h.acted = new Set([uid]);
        h.lastAction[uid] = `เก +${k * this.ante}`;
        this.message = `${name} เก +${k * this.ante} (เดิมพันรอบนี้ ${newBet})`;
        this.emitFx('chip');
      } else {
        return fail('คำสั่งไม่ถูกต้อง');
      }
      await this.afterAction(uid);
      return { ok: true };
    });
  }

  async afterAction(actorUid) {
    const h = this.hand;
    clearTimeout(this.turnTimer);
    await this.refreshCredits();
    if (actorUid) this.pushMe(actorUid);
    const active = this.activeUids();
    if (active.length <= 1) return this.finishByFold();
    const done = active.every((u) => h.acted.has(u) && (h.roundBet[u] || 0) === h.currentBet);
    if (done) {
      h.turnUid = null;
      h.turnEndsAt = null;
      return h.phase === 'bet1' ? this.drawThird() : this.showdown();
    }
    // หาคนถัดไปที่ยังต้องตัดสินใจ
    const order = h.order;
    let i = order.indexOf(h.turnUid);
    for (let n = 0; n < order.length; n++) {
      i = (i + 1) % order.length;
      const u = order[i];
      if (h.folded.has(u)) continue;
      if (!h.acted.has(u) || (h.roundBet[u] || 0) < h.currentBet) {
        this.setTurn(u);
        this.broadcast();
        return;
      }
    }
    return h.phase === 'bet1' ? this.drawThird() : this.showdown();
  }

  async drawThird() {
    const h = this.hand;
    h.phase = 'draw';
    h.turnUid = null;
    h.turnEndsAt = null;
    for (const u of this.activeUids()) h.cards[u].push(h.deck.pop());
    this.message = 'แจกไพ่ใบที่ 3 ให้ผู้เล่นที่ยังอยู่';
    this.emitFx('deal');
    this.broadcast();
    this.schedule(config.drawPauseMs, () => this.startBetting(2));
  }

  async showdown() {
    const h = this.hand;
    h.phase = 'showdown';
    const reveals = {};
    let best = null;
    for (const u of this.activeUids()) {
      const ev = evaluate(h.cards[u]);
      reveals[u] = { cards: h.cards[u], label: ev.label };
      if (!best || compareHands(ev, best.ev) > 0) best = { uid: u, ev };
    }
    await this.settle(best.uid, false, reveals);
  }

  async finishByFold() {
    const h = this.hand;
    if (!h || !h.live) return;
    const winner = this.activeUids()[0] ?? h.order[0];
    await this.settle(winner, true, {});
  }

  async settle(winnerUid, byFold, reveals) {
    const h = this.hand;
    if (!h || !h.live) return;
    h.live = false;
    clearTimeout(this.turnTimer);
    h.turnUid = null;
    h.turnEndsAt = null;
    const labels = Object.fromEntries(Object.entries(reveals).map(([u, r]) => [u, r.label]));
    const deltas = await settleHand({
      roomCode: this.code,
      handNo: this.handNo,
      pot: h.pot,
      contrib: h.contrib,
      winnerUid,
      byFold,
      labels,
    });
    for (const [u, d] of Object.entries(deltas)) this.sessionNet[u] = (this.sessionNet[u] || 0) + d;
    await this.refreshCredits();
    const winner = this.player(winnerUid);
    h.phase = 'result';
    h.result = { winnerUid, winnerName: winner?.name ?? 'ผู้เล่น', pot: h.pot, byFold, reveals, deltas };
    this.message = byFold
      ? `${h.result.winnerName} ชนะหม้อ ${h.pot} (ที่เหลือหมอบหมด)`
      : `${h.result.winnerName} ชนะหม้อ ${h.pot} ด้วย ${reveals[winnerUid]?.label ?? ''}`;
    this.emitFx(byFold ? 'win' : 'reveal');
    if (!byFold) setTimeout(() => this.emitFx('win'), 1000);
    this.broadcast();
    this.schedule(config.resultPauseMs, () => this.nextHand());
  }

  async nextHand() {
    if (this.settings.rounds > 0 && this.handNo >= this.settings.rounds) return this.endGame('ครบจำนวนตาที่ตั้งไว้');
    await this.beginHand();
  }

  endGame(reason) {
    clearTimeout(this.stepTimer);
    clearTimeout(this.turnTimer);
    this.stepId++;
    this.cleanupRoster();
    if (this.destroyed) return;
    this.status = 'finished';
    this.hand = null;
    this.finishInfo = {
      reason,
      hands: this.handNo,
      net: this.players.map((p) => ({ userId: p.userId, name: p.name, net: this.sessionNet[p.userId] || 0 })),
    };
    this.message = `จบเกม — ${reason}`;
    this.emitFx('win');
    this.broadcast();
  }

  // ---------- ส่งสถานะ ----------
  /** มุมมองเฉพาะผู้เล่น: เห็นเฉพาะไพ่ตัวเอง และไพ่คนอื่นเมื่อถึงตอนเปิดไพ่เท่านั้น */
  viewFor(uid) {
    const h = this.hand;
    const reveals = h?.result && !h.result.byFold ? h.result.reveals : {};
    const players = this.players.map((p) => {
      const inHand = !!h && h.order.includes(p.userId);
      const rev = reveals[p.userId];
      return {
        userId: p.userId,
        name: p.name,
        seat: p.seat,
        credits: p.credits,
        online: p.online,
        left: p.left,
        isOwner: p.userId === this.ownerId,
        inHand,
        folded: inHand && h.folded.has(p.userId),
        sittingOut: this.status === 'playing' && !inHand,
        cardCount: inHand ? h.cards[p.userId].length : 0,
        // ไพ่ของคนอื่นเป็น null เสมอ ยกเว้นตอนเปิดไพ่ตัดสิน
        cards: p.userId === uid ? (inHand ? h.cards[p.userId] : []) : rev ? rev.cards : null,
        handLabel: rev ? rev.label : null,
        roundBet: inHand ? h.roundBet[p.userId] || 0 : 0,
        contrib: inHand ? h.contrib[p.userId] || 0 : 0,
        lastAction: inHand ? h.lastAction[p.userId] || null : null,
        net: this.sessionNet[p.userId] || 0,
      };
    });
    const myTurn = !!h && h.live && h.turnUid === uid && ['bet1', 'bet2'].includes(h.phase);
    const myCards = h && h.order.includes(uid) ? h.cards[uid] : [];
    return {
      code: this.code,
      ownerId: this.ownerId,
      settings: this.settings,
      status: this.status,
      handNo: this.handNo,
      phase: h ? h.phase : this.status === 'finished' ? 'over' : 'waiting',
      pot: h ? h.pot : 0,
      currentBet: h ? h.currentBet : 0,
      turnUid: h ? h.turnUid : null,
      turnEndsAt: h ? h.turnEndsAt : null,
      serverNow: Date.now(),
      message: this.message,
      players,
      you: {
        userId: uid,
        myLabel: myCards.length ? evaluate(myCards).label : null,
        canAct: myTurn,
        toCall: myTurn ? Math.max(0, h.currentBet - (h.roundBet[uid] || 0)) : 0,
        maxRaiseK: myTurn ? this.maxRaiseK() : 0,
      },
      result: h?.result
        ? { winnerUid: h.result.winnerUid, winnerName: h.result.winnerName, pot: h.result.pot, byFold: h.result.byFold, deltas: h.result.deltas }
        : null,
      finishInfo: this.finishInfo,
    };
  }

  broadcast() {
    if (this.destroyed) return;
    for (const p of this.players) emitToUser(p.userId, 'room:state', this.viewFor(p.userId));
    broadcastLobby();
  }

  summary() {
    const owner = this.player(this.ownerId);
    return {
      code: this.code,
      owner: owner?.name ?? '-',
      ante: this.settings.ante,
      players: this.players.filter((p) => !p.left).length,
      maxPlayers: this.settings.maxPlayers,
      turnTime: this.settings.turnTime,
      rounds: this.settings.rounds,
      status: this.status,
    };
  }
}

let lobbyTimer = null;
export function listRooms() {
  return [...hub.rooms.values()].map((r) => r.summary());
}
export function broadcastLobby() {
  if (lobbyTimer) return;
  lobbyTimer = setTimeout(() => {
    lobbyTimer = null;
    hub.io?.to('lobby').emit('lobby:rooms', listRooms());
  }, 150);
}

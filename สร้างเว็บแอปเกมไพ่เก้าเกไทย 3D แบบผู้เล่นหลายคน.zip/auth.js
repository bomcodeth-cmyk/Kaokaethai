// ระบบบัญชี: ชื่อผู้ใช้ + รหัสผ่านเท่านั้น (ไม่มีอีเมล ไม่มี OTP ไม่มีลิงก์ยืนยัน)
import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from './db.js';
import { config } from './config.js';

export const router = express.Router();

const USERNAME_RE = /^[\p{L}\p{N}_.-]+$/u;

export function publicUser(u) {
  return { id: u.id, username: u.username, credits: u.credits, wins: u.wins, losses: u.losses };
}

export function signToken(user) {
  return jwt.sign({ uid: user.id, tv: user.tokenVersion }, config.jwtSecret, { expiresIn: `${config.tokenDays}d` });
}

/** ตรวจโทเคน -> คืน user หรือ null (โทเคนเก่าหลังรีเซ็ตรหัสผ่าน/บัญชีที่ถูกลบจะใช้ไม่ได้) */
export async function userFromToken(token) {
  if (!token) return null;
  try {
    const p = jwt.verify(token, config.jwtSecret);
    if (!p.uid) return null;
    const user = await prisma.user.findUnique({ where: { id: p.uid } });
    if (!user || user.tokenVersion !== p.tv) return null;
    return user;
  } catch {
    return null;
  }
}

export async function requireUser(req, res, next) {
  const h = req.headers.authorization || '';
  const user = await userFromToken(h.startsWith('Bearer ') ? h.slice(7) : null);
  if (!user) return res.status(401).json({ error: 'กรุณาเข้าสู่ระบบใหม่' });
  req.user = user;
  next();
}

// กันเดารหัสผ่าน: จำกัดจำนวนครั้งต่อ IP+ชื่อผู้ใช้
const attempts = new Map();
function throttled(key) {
  const now = Date.now();
  const rec = (attempts.get(key) || []).filter((t) => now - t < 60_000);
  attempts.set(key, rec);
  return rec.length >= 10;
}
function noteAttempt(key) {
  attempts.set(key, [...(attempts.get(key) || []), Date.now()]);
}

function validate(username, password) {
  if (typeof username !== 'string' || typeof password !== 'string') return 'ข้อมูลไม่ถูกต้อง';
  if (username.length < config.username.min || username.length > config.username.max)
    return `ชื่อผู้ใช้ต้องยาว ${config.username.min}-${config.username.max} ตัวอักษร`;
  if (!USERNAME_RE.test(username)) return 'ชื่อผู้ใช้ใช้ได้เฉพาะตัวอักษร ตัวเลข _ . - (ห้ามเว้นวรรค)';
  if (password.length < config.passwordMin) return `รหัสผ่านต้องมีอย่างน้อย ${config.passwordMin} ตัวอักษร`;
  if (password.length > 100) return 'รหัสผ่านยาวเกินไป';
  return null;
}

router.post('/register', async (req, res) => {
  const { username, password } = req.body || {};
  const err = validate(username, password);
  if (err) return res.status(400).json({ error: err });
  const lower = username.toLowerCase();
  if (await prisma.user.findUnique({ where: { usernameLower: lower } }))
    return res.status(409).json({ error: 'ชื่อผู้ใช้นี้ถูกใช้แล้ว' });
  try {
    const user = await prisma.user.create({
      data: {
        username,
        usernameLower: lower,
        passwordHash: await bcrypt.hash(password, 10),
        credits: config.startCredits,
      },
    });
    res.json({ token: signToken(user), user: publicUser(user) });
  } catch (e) {
    if (e.code === 'P2002') return res.status(409).json({ error: 'ชื่อผู้ใช้นี้ถูกใช้แล้ว' });
    console.error(e);
    res.status(500).json({ error: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' });
  }
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string') return res.status(400).json({ error: 'ข้อมูลไม่ถูกต้อง' });
  const key = `${req.ip}|${username.toLowerCase()}`;
  if (throttled(key)) return res.status(429).json({ error: 'ลองผิดบ่อยเกินไป กรุณารอ 1 นาทีแล้วลองใหม่' });
  const user = await prisma.user.findUnique({ where: { usernameLower: username.toLowerCase() } });
  const ok = user && (await bcrypt.compare(password, user.passwordHash));
  if (!ok) {
    noteAttempt(key);
    return res.status(401).json({ error: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
  }
  await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
  res.json({ token: signToken(user), user: publicUser(user) });
});

router.get('/me', requireUser, (req, res) => res.json({ user: publicUser(req.user) }));

router.get('/history', requireUser, async (req, res) => {
  const records = await prisma.handRecord.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
  res.json({ user: publicUser(req.user), records });
});

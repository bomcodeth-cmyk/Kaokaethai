import express from 'express';
import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import cors from 'cors';
import { Server } from 'socket.io';
import { config } from './config.js';
import { prisma } from './db.js';
import { hub, isOnline, notifyAdmins } from './state.js';
import { router as authRouter, userFromToken } from './auth.js';
import { router as adminRouter, verifyAdminToken } from './admin.js';
import { Room, newCode, listRooms, broadcastLobby } from './room.js';
import { refundStaleEscrow } from './wallet.js';

const app = express();
app.set('trust proxy', 1);
app.use(cors());
app.use(express.json({ limit: '10kb' }));
app.use('/api/auth', authRouter);
app.use('/api/admin', adminRouter);
app.get('/api/health', (_req, res) => res.json({ ok: true, rooms: hub.rooms.size }));
app.get('/api/config', (_req, res) =>
  res.json({
    startCredits: config.startCredits,
    roundOptions: config.roundOptions,
    turnTimeOptions: config.turnTimeOptions,
    maxPlayersRange: config.maxPlayersRange,
    anteRange: config.anteRange,
    joinMultiplier: config.joinMultiplier,
    maxRaiseK: config.maxRaiseK,
    username: config.username,
    passwordMin: config.passwordMin,
  }),
);

// เสิร์ฟหน้าเว็บที่ build แล้ว (โหมด production)
const dist = path.join(config.root, 'client', 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^\/(?!api|socket\.io).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true }, pingInterval: 10000, pingTimeout: 8000 });
hub.io = io;

// ตรวจโทเคนก่อนอนุญาตให้ต่อ socket
io.use(async (socket, next) => {
  const user = await userFromToken(socket.handshake.auth?.token);
  if (!user) return next(new Error('unauthorized'));
  socket.data.userId = user.id;
  next();
});

const validOption = (v, list) => list.includes(v);

io.on('connection', async (socket) => {
  const uid = socket.data.userId;
  if (!hub.sockets.has(uid)) hub.sockets.set(uid, new Set());
  hub.sockets.get(uid).add(socket);
  socket.join('lobby');
  notifyAdmins();

  // กลับเข้าโต๊ะเดิมอัตโนมัติ (รีเฟรชหน้า/หลุดแล้วกลับมา)
  const code = hub.userRoom.get(uid);
  const existing = code && hub.rooms.get(code);
  if (existing) {
    socket.join(`room:${code}`);
    existing.run(async () => existing.setOnline(uid, true));
  }

  const me = () => prisma.user.findUnique({ where: { id: uid } });
  const reply = (cb, payload) => typeof cb === 'function' && cb(payload);
  // ป้องกันการกดซ้ำรัว ๆ: จำกัดอัตราต่อ socket
  let tokens = 12;
  const refill = setInterval(() => (tokens = Math.min(12, tokens + 4)), 1000);
  const limited = () => tokens-- <= 0;

  socket.on('lobby:list', (cb) => reply(cb, listRooms()));

  socket.on('room:create', async (opts, cb) => {
    try {
      if (limited()) return reply(cb, { ok: false, error: 'ทำรายการถี่เกินไป' });
      if (hub.userRoom.has(uid)) return reply(cb, { ok: false, error: 'คุณกำลังอยู่ในโต๊ะอื่น กรุณาออกก่อน' });
      const rounds = Number(opts?.rounds);
      const maxPlayers = Number(opts?.maxPlayers);
      const turnTime = Number(opts?.turnTime);
      const ante = Math.floor(Number(opts?.ante));
      const [pmin, pmax] = config.maxPlayersRange;
      const [amin, amax] = config.anteRange;
      if (!validOption(rounds, config.roundOptions)) return reply(cb, { ok: false, error: 'จำนวนตาไม่ถูกต้อง' });
      if (!Number.isInteger(maxPlayers) || maxPlayers < pmin || maxPlayers > pmax) return reply(cb, { ok: false, error: 'จำนวนผู้เล่นต้อง 2-6 คน' });
      if (!validOption(turnTime, config.turnTimeOptions)) return reply(cb, { ok: false, error: 'เวลาต่อตาไม่ถูกต้อง' });
      if (!Number.isFinite(ante) || ante < amin || ante > amax) return reply(cb, { ok: false, error: `ค่าต๋งต้องอยู่ระหว่าง ${amin}-${amax}` });
      const user = await me();
      if (!user) return reply(cb, { ok: false, error: 'ไม่พบบัญชี' });
      const room = new Room({ code: newCode(), owner: user, settings: { rounds, maxPlayers, turnTime, ante } });
      hub.rooms.set(room.code, room);
      const r = await room.join(user);
      if (!r.ok) {
        room.destroy();
        return reply(cb, r);
      }
      socket.join(`room:${room.code}`);
      broadcastLobby();
      reply(cb, { ok: true, code: room.code });
    } catch (e) {
      console.error(e);
      reply(cb, { ok: false, error: 'เกิดข้อผิดพลาด' });
    }
  });

  socket.on('room:join', async (payload, cb) => {
    try {
      if (limited()) return reply(cb, { ok: false, error: 'ทำรายการถี่เกินไป' });
      const want = String(payload?.code || '').trim().toUpperCase();
      const current = hub.userRoom.get(uid);
      if (current && current !== want) return reply(cb, { ok: false, error: `คุณอยู่ในโต๊ะ ${current} อยู่ กรุณาออกก่อน` });
      const room = hub.rooms.get(want);
      if (!room) return reply(cb, { ok: false, error: 'ไม่พบรหัสห้องนี้' });
      const user = await me();
      if (!user) return reply(cb, { ok: false, error: 'ไม่พบบัญชี' });
      const r = await room.join(user);
      if (r.ok) {
        for (const s of hub.sockets.get(uid) || []) s.join(`room:${want}`);
        notifyAdmins();
      }
      reply(cb, { ...r, code: want });
    } catch (e) {
      console.error(e);
      reply(cb, { ok: false, error: 'เกิดข้อผิดพลาด' });
    }
  });

  socket.on('room:leave', async (cb) => {
    try {
      const code = hub.userRoom.get(uid);
      const room = code && hub.rooms.get(code);
      if (room) await room.leave(uid);
      for (const s of hub.sockets.get(uid) || []) {
        s.leave(`room:${code}`);
        s.emit('room:left');
      }
      notifyAdmins();
      reply(cb, { ok: true });
    } catch (e) {
      console.error(e);
      reply(cb, { ok: false });
    }
  });

  socket.on('room:start', async (cb) => {
    try {
      const room = hub.rooms.get(hub.userRoom.get(uid));
      if (!room) return reply(cb, { ok: false, error: 'ไม่ได้อยู่ในโต๊ะ' });
      reply(cb, await room.start(uid));
    } catch (e) {
      console.error(e);
      reply(cb, { ok: false, error: 'เกิดข้อผิดพลาด' });
    }
  });

  // การกระทำในเกม: เซิร์ฟเวอร์ตรวจว่าเป็นตาของ uid (จาก token ไม่ใช่จากข้อมูลที่ client ส่ง)
  socket.on('game:action', async (payload, cb) => {
    try {
      if (limited()) return reply(cb, { ok: false, error: 'กดถี่เกินไป' });
      const room = hub.rooms.get(hub.userRoom.get(uid));
      if (!room) return reply(cb, { ok: false, error: 'ไม่ได้อยู่ในโต๊ะ' });
      reply(cb, await room.action(uid, payload));
    } catch (e) {
      console.error(e);
      reply(cb, { ok: false, error: 'เกิดข้อผิดพลาด' });
    }
  });

  socket.on('room:sync', () => {
    const room = hub.rooms.get(hub.userRoom.get(uid));
    if (room) socket.emit('room:state', room.viewFor(uid));
    else socket.emit('room:left');
  });

  socket.on('admin:join', (token) => {
    if (verifyAdminToken(token)) socket.join('admins');
  });

  socket.on('disconnect', () => {
    clearInterval(refill);
    const set = hub.sockets.get(uid);
    set?.delete(socket);
    if (set && set.size === 0) {
      hub.sockets.delete(uid);
      const room = hub.rooms.get(hub.userRoom.get(uid));
      if (room) room.run(async () => room.setOnline(uid, false));
    }
    notifyAdmins();
  });

  // ส่งข้อมูลเริ่มต้นหลังเชื่อมต่อ
  const user = await me();
  if (user) socket.emit('me:credits', { credits: user.credits });
  socket.emit('lobby:rooms', listRooms());
  if (existing) socket.emit('room:state', existing.viewFor(uid));
});

await refundStaleEscrow();
server.listen(config.port, '0.0.0.0', () => {
  console.log(`เก้าเกไทย server พร้อมแล้วที่ http://localhost:${config.port}`);
  if (!fs.existsSync(dist)) console.log('(ยังไม่ได้ build หน้าเว็บ — ใช้ npm run dev หรือ npm run build)');
});

process.on('unhandledRejection', (e) => console.error('unhandledRejection', e));
export { isOnline };
